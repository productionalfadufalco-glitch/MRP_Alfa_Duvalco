'use strict';
/**
 * ALFA VALVES MRP - Storage engine selector.
 *
 * Tries the fast native engine (SQLite) first. If better-sqlite3 is missing
 * or cannot load — which happens on locked-down PCs without Administrator
 * rights, without a C++ compiler, or when the corporate network blocks the
 * prebuilt-binary download — it falls back to the pure-JavaScript engine.
 *
 * Both engines expose an identical API, so the rest of the app is unaffected.
 * Force a specific engine with:  ALFA_ENGINE=json  or  ALFA_ENGINE=sqlite
 */
const forced = (process.env.ALFA_ENGINE || '').toLowerCase();

function loadSqlite() {
  const mod = require('./db');
  mod.engine = 'sqlite';
  return mod;
}
function loadJson() {
  return require('./storage-json');
}

let storage;

if (forced === 'json') {
  storage = loadJson();
  console.log('[storage] Engine: pure-JavaScript (dipaksa lewat ALFA_ENGINE=json)');
} else if (forced === 'sqlite') {
  storage = loadSqlite();
  console.log('[storage] Engine: SQLite (dipaksa lewat ALFA_ENGINE=sqlite)');
} else {
  try {
    storage = loadSqlite();
    console.log('[storage] Engine: SQLite (native, performa maksimal)');
  } catch (err) {
    storage = loadJson();
    console.log('');
    console.log('[storage] better-sqlite3 tidak tersedia -> memakai engine JavaScript murni.');
    console.log('          Alasan: ' + (err.code || err.message));
    console.log('          Aplikasi tetap berjalan penuh. Semua data tersimpan aman');
    console.log('          di folder data/ dan tahan mati listrik.');
    console.log('');
  }
}

module.exports = storage;
