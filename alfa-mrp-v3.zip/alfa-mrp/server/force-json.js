// Preload helper: forces the pure-JavaScript storage engine.
// Used by "npm run start:json".
process.env.ALFA_ENGINE = 'json';
