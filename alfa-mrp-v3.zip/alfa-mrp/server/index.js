'use strict';
/**
 * ALFA VALVES INDONESIA - MRP System
 * Express REST API + WebSocket live-sync server.
 */
const path = require('path');
const fs = require('fs');
const http = require('http');
const express = require('express');
const compression = require('compression');
const { WebSocketServer } = require('ws');
const DB = require('./storage');

const PORT = process.env.PORT || 3000;
const HOST = '0.0.0.0';
const AUTH_ENABLED = process.env.ALFA_AUTH === '1'; // off by default for LAN use

const app = express();
app.set('trust proxy', true);
app.use(compression());
app.use(express.json({ limit: '256mb' }));   // large Excel imports
app.use(express.urlencoded({ extended: true, limit: '256mb' }));

/* Allow the sandbox preview host / any LAN origin */
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Alfa-Token, X-Client-Id');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

/* ---------------- Auth (optional) ---------------- */
function actorOf(req) {
  const u = DB.getSession(req.headers['x-alfa-token']);
  return u ? u.username : (req.headers['x-client-id'] || 'anon');
}
function guard(req, res, next) {
  if (!AUTH_ENABLED) return next();
  const u = DB.getSession(req.headers['x-alfa-token']);
  if (!u) return res.status(401).json({ error: 'unauthorized' });
  req.user = u;
  next();
}

app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  const u = DB.authenticate(username, password);
  if (!u) return res.status(401).json({ error: 'invalid credentials' });
  const token = DB.createSession(u.username, 30);
  DB.audit(u.username, 'login', null, null, null, null);
  res.json({ token, user: u });
});
app.post('/api/logout', (req, res) => {
  DB.destroySession(req.headers['x-alfa-token']);
  res.json({ ok: true });
});
app.get('/api/me', (req, res) => {
  const u = DB.getSession(req.headers['x-alfa-token']);
  res.json({ authEnabled: AUTH_ENABLED, user: u || null });
});

/* ---------------- Core sync API ---------------- */

// Full state snapshot
app.get('/api/state', guard, (req, res) => {
  const s = DB.getState();
  res.json({ ok: true, rev: s.rev, data: s.data, settings: DB.getAllSettings() });
});

// Seed once (first boot only) — client ships the built-in demo dataset
app.post('/api/seed', guard, (req, res) => {
  if (!DB.isEmpty()) return res.json({ ok: true, seeded: false, reason: 'database already populated' });
  DB.seedAll(req.body || {});
  const s = DB.getState();
  broadcast({ type: 'state', rev: s.rev, data: s.data }, null);
  res.json({ ok: true, seeded: true, rev: s.rev });
});

// Sync one collection (diff-based write)
app.post('/api/sync/:collection', guard, (req, res) => {
  const c = req.params.collection;
  if (!DB.COLLECTIONS.includes(c)) return res.status(400).json({ error: 'unknown collection: ' + c });
  const rows = Array.isArray(req.body) ? req.body : (req.body && req.body.rows);
  if (!Array.isArray(rows)) return res.status(400).json({ error: 'expected an array of rows' });
  const actor = actorOf(req);
  const out = DB.syncCollection(c, rows, actor);
  if (out.changed > 0) {
    broadcast({ type: 'collection', collection: c, rows, rev: out.rev, actor }, req.headers['x-client-id']);
  }
  res.json({ ok: true, ...out });
});

// Sync many collections at once
app.post('/api/sync', guard, (req, res) => {
  const payload = req.body || {};
  const actor = actorOf(req);
  const results = [];
  for (const c of DB.COLLECTIONS) {
    if (Array.isArray(payload[c])) results.push(DB.syncCollection(c, payload[c], actor));
  }
  const changed = results.reduce((s, r) => s + r.changed, 0);
  if (changed > 0) {
    const s = DB.getState();
    broadcast({ type: 'state', rev: s.rev, data: s.data, actor }, req.headers['x-client-id']);
  }
  res.json({ ok: true, changed, rev: DB.getRev(), results });
});

// Granular record ops
app.put('/api/record/:collection', guard, (req, res) => {
  const c = req.params.collection;
  if (!DB.COLLECTIONS.includes(c)) return res.status(400).json({ error: 'unknown collection' });
  const out = DB.upsertRecord(c, req.body, actorOf(req));
  broadcast({ type: 'record', collection: c, record: out.record, rev: out.rev }, req.headers['x-client-id']);
  res.json({ ok: true, ...out });
});
app.delete('/api/record/:collection/:id', guard, (req, res) => {
  const c = req.params.collection;
  if (!DB.COLLECTIONS.includes(c)) return res.status(400).json({ error: 'unknown collection' });
  const out = DB.deleteRecord(c, req.params.id, actorOf(req));
  broadcast({ type: 'delete', collection: c, id: req.params.id, rev: out.rev }, req.headers['x-client-id']);
  res.json({ ok: true, ...out });
});

// Delta feed for reconnects
app.get('/api/changes', guard, (req, res) => {
  res.json(DB.changesSince(parseInt(req.query.since || '0', 10)));
});

// Settings (theme / language / per-app prefs)
app.get('/api/settings', guard, (req, res) => res.json(DB.getAllSettings()));
app.post('/api/settings', guard, (req, res) => {
  const body = req.body || {};
  Object.keys(body).forEach(k => DB.setSetting(k, body[k]));
  res.json({ ok: true, settings: DB.getAllSettings() });
});

/* ---------------- Ops / admin ---------------- */
app.get('/api/health', (req, res) => {
  res.json({ ok: true, status: 'up', time: new Date().toISOString(), clients: wss ? wss.clients.size : 0, ...DB.stats() });
});
app.get('/api/audit', guard, (req, res) => res.json(DB.recentAudit(parseInt(req.query.limit || '100', 10))));

app.post('/api/backup', guard, async (req, res) => {
  try { res.json({ ok: true, ...(await DB.backup()) }); }
  catch (e) { res.status(500).json({ error: String(e.message || e) }); }
});
app.get('/api/backup/download', guard, async (req, res) => {
  try {
    const b = await DB.backup();
    res.download(b.path, b.file);
  } catch (e) { res.status(500).json({ error: String(e.message || e) }); }
});
app.get('/api/backups', guard, (req, res) => {
  const dir = path.join(DB.DATA_DIR, 'backups');
  if (!fs.existsSync(dir)) return res.json([]);
  res.json(fs.readdirSync(dir).filter(f => f.endsWith('.db')).sort().reverse().map(f => {
    const st = fs.statSync(path.join(dir, f));
    return { file: f, bytes: st.size, size: DB.human(st.size), mtime: st.mtime.toISOString() };
  }));
});
app.post('/api/maintenance/:op', guard, (req, res) => {
  try {
    const op = req.params.op;
    if (op === 'checkpoint') { DB.checkpoint(); return res.json({ ok: true, op }); }
    if (op === 'vacuum')     { DB.vacuum();     return res.json({ ok: true, op }); }
    if (op === 'integrity')  { return res.json({ ok: true, op, result: DB.integrityCheck() }); }
    res.status(400).json({ error: 'unknown op' });
  } catch (e) { res.status(500).json({ error: String(e.message || e) }); }
});

// Full JSON export (portable, human-readable archive)
app.get('/api/export/json', guard, (req, res) => {
  const s = DB.getState();
  res.setHeader('Content-Disposition',
    'attachment; filename="alfa_mrp_export_' + new Date().toISOString().slice(0, 10) + '.json"');
  res.json({ exportedAt: new Date().toISOString(), rev: s.rev, data: s.data, settings: DB.getAllSettings() });
});

/* ---------------- Static app ---------------- */
app.use(express.static(path.join(__dirname, '..', 'public'), {
  maxAge: '1h',
  setHeaders: (res, p) => { if (p.endsWith('.html')) res.setHeader('Cache-Control', 'no-cache'); }
}));
// SPA fallback (Express 5 safe: no wildcard path pattern)
app.use((req, res, next) => {
  if (req.method !== 'GET') return next();
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'not found' });
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

/* ---------------- HTTP + WebSocket ---------------- */
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

function broadcast(msg, exceptClientId) {
  const payload = JSON.stringify(msg);
  wss.clients.forEach(ws => {
    if (ws.readyState !== 1) return;
    if (exceptClientId && ws.__clientId === exceptClientId) return; // don't echo to sender
    try { ws.send(payload); } catch (e) {}
  });
}

wss.on('connection', (ws, req) => {
  ws.__alive = true;
  ws.__clientId = null;
  ws.on('pong', () => { ws.__alive = true; });

  const s = DB.getState();
  ws.send(JSON.stringify({ type: 'hello', rev: s.rev, data: s.data, settings: DB.getAllSettings(), clients: wss.clients.size }));

  ws.on('message', raw => {
    let m; try { m = JSON.parse(raw); } catch (e) { return; }
    if (m.type === 'ident') { ws.__clientId = m.clientId; ws.__user = m.user || 'anon'; return; }
    if (m.type === 'ping')  { ws.send(JSON.stringify({ type: 'pong', t: Date.now() })); return; }

    if (m.type === 'sync' && m.collection && Array.isArray(m.rows)) {
      if (!DB.COLLECTIONS.includes(m.collection)) return;
      const out = DB.syncCollection(m.collection, m.rows, ws.__user || 'anon');
      ws.send(JSON.stringify({ type: 'ack', collection: m.collection, ...out }));
      if (out.changed > 0) {
        broadcast({ type: 'collection', collection: m.collection, rows: m.rows, rev: out.rev, actor: ws.__user }, ws.__clientId);
      }
    }
  });

  wss.clients.forEach(c => { if (c.readyState === 1) c.send(JSON.stringify({ type: 'presence', clients: wss.clients.size })); });
  ws.on('close', () => {
    wss.clients.forEach(c => { if (c.readyState === 1) c.send(JSON.stringify({ type: 'presence', clients: wss.clients.size })); });
  });
});

// Heartbeat: drop dead sockets so presence stays accurate
setInterval(() => {
  wss.clients.forEach(ws => {
    if (ws.__alive === false) return ws.terminate();
    ws.__alive = false;
    try { ws.ping(); } catch (e) {}
  });
}, 30000);

/* ---------------- Scheduled maintenance ---------------- */
setInterval(() => { try { DB.checkpoint(); } catch (e) {} }, 10 * 60 * 1000);      // WAL checkpoint /10 min
setInterval(() => { DB.backup().catch(() => {}); }, 6 * 60 * 60 * 1000);           // auto backup /6 h

/* ---------------- Bootstrap ---------------- */
if (AUTH_ENABLED && DB.userCount() === 0) {
  DB.createUser('admin', process.env.ALFA_ADMIN_PW || 'alfa2026', 'admin', 'Administrator');
  console.log('[auth] default admin created (username: admin)');
}

server.listen(PORT, HOST, () => {
  const s = DB.stats();
  console.log('==============================================');
  console.log(' PT. ALFA VALVES INDONESIA - MRP System');
  console.log(' Server  : http://' + HOST + ':' + PORT);
  console.log(' Database: ' + s.dbFile);
  console.log(' Size    : ' + s.dbSize + '  | rev ' + s.rev + ' | engine=' + (DB.engine || 'sqlite'));
  console.log(' Auth    : ' + (AUTH_ENABLED ? 'ENABLED' : 'disabled (LAN mode)'));
  console.log('==============================================');
});

process.on('SIGTERM', () => { try { DB.checkpoint(); } catch (e) {} process.exit(0); });
process.on('SIGINT',  () => { try { DB.checkpoint(); } catch (e) {} process.exit(0); });
