'use strict';
/**
 * ALFA VALVES MRP - Database Layer
 * SQLite (WAL mode) via better-sqlite3.
 * Durable, single-file, handles multi-GB datasets and millions of rows.
 */
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const Database = require('better-sqlite3');

const DATA_DIR = path.join(__dirname, '..', 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const DB_PATH = process.env.ALFA_DB || path.join(DATA_DIR, 'alfa_mrp.db');

const db = new Database(DB_PATH);

/* ---------- Durability & performance pragmas ---------- */
db.pragma('journal_mode = WAL');      // concurrent readers + crash safe
db.pragma('synchronous = FULL');      // never lose a committed transaction
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 8000');
db.pragma('cache_size = -64000');     // 64 MB page cache
db.pragma('temp_store = MEMORY');
db.pragma('mmap_size = 268435456');   // 256 MB memory map for big files

/* ---------- Schema ---------- */
db.exec(`
CREATE TABLE IF NOT EXISTS records (
  collection  TEXT    NOT NULL,
  id          TEXT    NOT NULL,
  data        TEXT    NOT NULL,
  rev         INTEGER NOT NULL,
  deleted     INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
  updated_at  TEXT    NOT NULL DEFAULT (datetime('now')),
  updated_by  TEXT,
  PRIMARY KEY (collection, id)
);
CREATE INDEX IF NOT EXISTS idx_records_rev        ON records(rev);
CREATE INDEX IF NOT EXISTS idx_records_collection ON records(collection, deleted);

CREATE TABLE IF NOT EXISTS meta (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
  seq        INTEGER PRIMARY KEY AUTOINCREMENT,
  ts         TEXT NOT NULL DEFAULT (datetime('now')),
  actor      TEXT,
  action     TEXT NOT NULL,
  collection TEXT,
  record_id  TEXT,
  before     TEXT,
  after      TEXT
);
CREATE INDEX IF NOT EXISTS idx_audit_ts   ON audit_log(ts);
CREATE INDEX IF NOT EXISTS idx_audit_coll ON audit_log(collection, record_id);

CREATE TABLE IF NOT EXISTS users (
  username   TEXT PRIMARY KEY,
  pass_hash  TEXT NOT NULL,
  salt       TEXT NOT NULL,
  role       TEXT NOT NULL DEFAULT 'operator',
  full_name  TEXT,
  active     INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sessions (
  token      TEXT PRIMARY KEY,
  username   TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  expires_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_exp ON sessions(expires_at);
`);

/* ---------- Revision counter (global, monotonic) ---------- */
function getRev() {
  const r = db.prepare(`SELECT value FROM meta WHERE key='rev'`).get();
  return r ? parseInt(r.value, 10) : 0;
}
function bumpRev() {
  const next = getRev() + 1;
  db.prepare(`INSERT INTO meta(key,value) VALUES('rev',?)
              ON CONFLICT(key) DO UPDATE SET value=excluded.value`).run(String(next));
  return next;
}
if (!db.prepare(`SELECT 1 FROM meta WHERE key='rev'`).get()) {
  db.prepare(`INSERT INTO meta(key,value) VALUES('rev','0')`).run();
}

/* ---------- Password helpers ---------- */
function hashPassword(pw, salt) {
  salt = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(pw), salt, 64).toString('hex');
  return { salt, hash };
}
function verifyPassword(pw, salt, expected) {
  const { hash } = hashPassword(pw, salt);
  const a = Buffer.from(hash, 'hex');
  const b = Buffer.from(expected, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

/* ---------- Collections managed by the app ---------- */
const COLLECTIONS = [
  'projects', 'variance', 'schedules', 'capacity',
  'mrlist', 'receipts', 'consumables', 'tools', 'machines'
];

/* ---------- Read whole state ---------- */
const selectAll = db.prepare(
  `SELECT id, data FROM records WHERE collection=? AND deleted=0 ORDER BY CAST(id AS INTEGER), id`
);
function getState() {
  const out = {};
  for (const c of COLLECTIONS) {
    out[c] = selectAll.all(c).map(r => JSON.parse(r.data));
  }
  return { rev: getRev(), data: out };
}

/* ---------- Settings (theme, lang, arbitrary key/value) ---------- */
function getSetting(key, fallback) {
  const r = db.prepare(`SELECT value FROM meta WHERE key=?`).get('set:' + key);
  return r ? JSON.parse(r.value) : fallback;
}
function setSetting(key, value) {
  db.prepare(`INSERT INTO meta(key,value) VALUES(?,?)
              ON CONFLICT(key) DO UPDATE SET value=excluded.value`)
    .run('set:' + key, JSON.stringify(value));
}
function getAllSettings() {
  const rows = db.prepare(`SELECT key,value FROM meta WHERE key LIKE 'set:%'`).all();
  const o = {};
  for (const r of rows) o[r.key.slice(4)] = JSON.parse(r.value);
  return o;
}

/* ---------- Audit ---------- */
const insAudit = db.prepare(
  `INSERT INTO audit_log(actor,action,collection,record_id,before,after) VALUES(?,?,?,?,?,?)`
);
function audit(actor, action, collection, id, before, after) {
  insAudit.run(actor || 'system', action, collection || null, id == null ? null : String(id),
    before ? JSON.stringify(before) : null, after ? JSON.stringify(after) : null);
}

/* ---------- Diff-based collection sync ----------
 * Client sends the full array for a collection; we write ONLY what changed.
 * Returns { changed, inserted, updated, deleted, rev }.
 */
const selExisting = db.prepare(`SELECT id, data, deleted FROM records WHERE collection=?`);
const insRec = db.prepare(
  `INSERT INTO records(collection,id,data,rev,deleted,updated_by)
   VALUES(?,?,?,?,0,?)
   ON CONFLICT(collection,id) DO UPDATE SET
     data=excluded.data, rev=excluded.rev, deleted=0,
     updated_at=datetime('now'), updated_by=excluded.updated_by`
);
const softDel = db.prepare(
  `UPDATE records SET deleted=1, rev=?, updated_at=datetime('now'), updated_by=?
   WHERE collection=? AND id=? AND deleted=0`
);

const syncCollection = db.transaction((collection, rows, actor) => {
  const rev = bumpRev();
  const existing = new Map();
  for (const r of selExisting.all(collection)) {
    existing.set(String(r.id), { data: r.data, deleted: r.deleted });
  }

  let inserted = 0, updated = 0, deleted = 0;
  const seen = new Set();

  rows.forEach((row, i) => {
    if (row == null || typeof row !== 'object') return;
    if (row.id === undefined || row.id === null || row.id === '') {
      row.id = Date.now() * 1000 + i; // stable-ish fallback id
    }
    const id = String(row.id);
    seen.add(id);
    const json = JSON.stringify(row);
    const prev = existing.get(id);
    if (!prev) {
      insRec.run(collection, id, json, rev, actor);
      inserted++;
      audit(actor, 'insert', collection, id, null, row);
    } else if (prev.data !== json || prev.deleted === 1) {
      insRec.run(collection, id, json, rev, actor);
      updated++;
      audit(actor, 'update', collection, id, safeParse(prev.data), row);
    }
  });

  for (const [id, prev] of existing) {
    if (!seen.has(id) && prev.deleted === 0) {
      softDel.run(rev, actor, collection, id);
      deleted++;
      audit(actor, 'delete', collection, id, safeParse(prev.data), null);
    }
  }

  const changed = inserted + updated + deleted;
  return { collection, changed, inserted, updated, deleted, rev };
});

function safeParse(s) { try { return JSON.parse(s); } catch (e) { return null; } }

/* ---------- Single record ops (granular API) ---------- */
function upsertRecord(collection, row, actor) {
  const rev = bumpRev();
  if (row.id === undefined || row.id === null || row.id === '') row.id = Date.now();
  const id = String(row.id);
  const prev = db.prepare(`SELECT data FROM records WHERE collection=? AND id=?`).get(collection, id);
  insRec.run(collection, id, JSON.stringify(row), rev, actor);
  audit(actor, prev ? 'update' : 'insert', collection, id, prev ? safeParse(prev.data) : null, row);
  return { rev, record: row };
}
function deleteRecord(collection, id, actor) {
  const rev = bumpRev();
  const prev = db.prepare(`SELECT data FROM records WHERE collection=? AND id=?`).get(collection, String(id));
  softDel.run(rev, actor, collection, String(id));
  audit(actor, 'delete', collection, id, prev ? safeParse(prev.data) : null, null);
  return { rev };
}

/* ---------- Changes feed (for reconnect / delta sync) ---------- */
function changesSince(sinceRev) {
  const rows = db.prepare(
    `SELECT collection, id, data, deleted, rev, updated_at, updated_by
     FROM records WHERE rev > ? ORDER BY rev ASC LIMIT 20000`
  ).all(sinceRev);
  return {
    rev: getRev(),
    changes: rows.map(r => ({
      collection: r.collection, id: r.id, deleted: !!r.deleted,
      rev: r.rev, updated_at: r.updated_at, updated_by: r.updated_by,
      data: r.deleted ? null : safeParse(r.data)
    }))
  };
}

/* ---------- Stats / health ---------- */
function stats() {
  const perColl = {};
  for (const c of COLLECTIONS) {
    const r = db.prepare(
      `SELECT COUNT(*) n, SUM(deleted) d, SUM(LENGTH(data)) bytes FROM records WHERE collection=?`
    ).get(c);
    perColl[c] = { rows: (r.n || 0) - (r.d || 0), archived: r.d || 0, bytes: r.bytes || 0 };
  }
  let fileBytes = 0, walBytes = 0;
  try { fileBytes = fs.statSync(DB_PATH).size; } catch (e) {}
  try { walBytes = fs.statSync(DB_PATH + '-wal').size; } catch (e) {}
  const audits = db.prepare(`SELECT COUNT(*) n FROM audit_log`).get().n;
  return {
    rev: getRev(), collections: perColl, auditEntries: audits,
    dbFile: DB_PATH, dbBytes: fileBytes, walBytes,
    dbSize: human(fileBytes), pageSize: db.pragma('page_size', { simple: true }),
    journalMode: db.pragma('journal_mode', { simple: true })
  };
}
function human(b) {
  if (b < 1024) return b + ' B';
  if (b < 1048576) return (b / 1024).toFixed(1) + ' KB';
  if (b < 1073741824) return (b / 1048576).toFixed(1) + ' MB';
  return (b / 1073741824).toFixed(2) + ' GB';
}

/* ---------- Backup (online, safe while running) ---------- */
async function backup() {
  const dir = path.join(DATA_DIR, 'backups');
  fs.mkdirSync(dir, { recursive: true });
  const name = 'alfa_mrp_' + new Date().toISOString().replace(/[:.]/g, '-') + '.db';
  const dest = path.join(dir, name);
  await db.backup(dest);
  // keep the newest 30 backups
  const files = fs.readdirSync(dir).filter(f => f.endsWith('.db')).sort();
  while (files.length > 30) { try { fs.unlinkSync(path.join(dir, files.shift())); } catch (e) {} }
  return { file: name, path: dest, bytes: fs.statSync(dest).size };
}

/* ---------- Maintenance ---------- */
function checkpoint() { db.pragma('wal_checkpoint(TRUNCATE)'); }
function integrityCheck() { return db.pragma('integrity_check', { simple: true }); }
function vacuum() { db.exec('VACUUM'); }

/* ---------- Seed on first boot ---------- */
function isEmpty() {
  return db.prepare(`SELECT COUNT(*) n FROM records`).get().n === 0;
}
const seedAll = db.transaction((seed) => {
  for (const c of COLLECTIONS) {
    if (Array.isArray(seed[c]) && seed[c].length) syncCollection(c, seed[c], 'seed');
  }
});

/* ---------- Users / sessions ---------- */
function createUser(username, password, role, fullName) {
  const { salt, hash } = hashPassword(password);
  db.prepare(`INSERT INTO users(username,pass_hash,salt,role,full_name) VALUES(?,?,?,?,?)
              ON CONFLICT(username) DO UPDATE SET pass_hash=excluded.pass_hash,
              salt=excluded.salt, role=excluded.role, full_name=excluded.full_name`)
    .run(username, hash, salt, role || 'operator', fullName || username);
  return { username, role: role || 'operator' };
}
function authenticate(username, password) {
  const u = db.prepare(`SELECT * FROM users WHERE username=? AND active=1`).get(username);
  if (!u) return null;
  if (!verifyPassword(password, u.salt, u.pass_hash)) return null;
  return { username: u.username, role: u.role, full_name: u.full_name };
}
function createSession(username, days) {
  const token = crypto.randomBytes(32).toString('hex');
  const exp = new Date(Date.now() + (days || 30) * 86400000).toISOString();
  db.prepare(`INSERT INTO sessions(token,username,expires_at) VALUES(?,?,?)`).run(token, username, exp);
  return token;
}
function getSession(token) {
  if (!token) return null;
  const s = db.prepare(`SELECT * FROM sessions WHERE token=?`).get(token);
  if (!s) return null;
  if (new Date(s.expires_at) < new Date()) {
    db.prepare(`DELETE FROM sessions WHERE token=?`).run(token);
    return null;
  }
  const u = db.prepare(`SELECT username, role, full_name FROM users WHERE username=? AND active=1`).get(s.username);
  return u || null;
}
function destroySession(token) {
  db.prepare(`DELETE FROM sessions WHERE token=?`).run(token);
}
function listUsers() {
  return db.prepare(`SELECT username, role, full_name, active, created_at FROM users ORDER BY username`).all();
}
function userCount() {
  return db.prepare(`SELECT COUNT(*) n FROM users`).get().n;
}

function recentAudit(limit) {
  return db.prepare(
    `SELECT seq, ts, actor, action, collection, record_id FROM audit_log
     ORDER BY seq DESC LIMIT ?`
  ).all(Math.min(limit || 100, 2000));
}

module.exports = {
  db, DB_PATH, DATA_DIR, COLLECTIONS,
  getState, getRev, syncCollection, upsertRecord, deleteRecord, changesSince,
  getSetting, setSetting, getAllSettings,
  stats, backup, checkpoint, integrityCheck, vacuum,
  isEmpty, seedAll, audit, recentAudit,
  createUser, authenticate, createSession, getSession, destroySession, listUsers, userCount,
  human
};
