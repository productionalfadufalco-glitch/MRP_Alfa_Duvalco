'use strict';
/**
 * ALFA VALVES MRP - Pure-JavaScript storage engine (FALLBACK)
 *
 * Used automatically when better-sqlite3 cannot be installed
 * (no Administrator rights / no compiler / corporate network blocks
 * the prebuilt binary download).
 *
 * Durability model — crash-safe without any native module:
 *   1. Every mutation is appended to an append-only journal (JSONL, fsync'd).
 *   2. Periodically the journal is compacted into a snapshot written
 *      atomically (temp file + rename, which is atomic on NTFS/ext4).
 *   3. On boot: load snapshot, then replay the journal tail.
 * A power cut can therefore lose nothing that was already acknowledged.
 */
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const DATA_DIR = path.join(__dirname, '..', 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });

const SNAP = path.join(DATA_DIR, 'alfa_mrp.snapshot.json');
const JOURNAL = path.join(DATA_DIR, 'alfa_mrp.journal.jsonl');
const AUDIT = path.join(DATA_DIR, 'alfa_mrp.audit.jsonl');
const DB_PATH = SNAP;

const COLLECTIONS = [
  'projects', 'variance', 'schedules', 'capacity',
  'mrlist', 'receipts', 'consumables', 'tools', 'machines'
];

/* ---------------- in-memory state ---------------- */
const MEM = {
  rev: 0,
  // collection -> Map(id -> {data, rev, deleted})
  records: {},
  settings: {},
  users: {},
  sessions: {}
};
COLLECTIONS.forEach(c => { MEM.records[c] = new Map(); });

let journalCount = 0;
let auditCount = 0;

/* ---------------- low-level durable append ---------------- */
function appendLine(file, obj) {
  const fd = fs.openSync(file, 'a');
  try {
    fs.writeSync(fd, JSON.stringify(obj) + '\n');
    fs.fsyncSync(fd);              // force to disk — survives power loss
  } finally {
    fs.closeSync(fd);
  }
}

function writeAtomic(file, text) {
  const tmp = file + '.tmp';
  const fd = fs.openSync(tmp, 'w');
  try {
    fs.writeSync(fd, text);
    fs.fsyncSync(fd);
  } finally {
    fs.closeSync(fd);
  }
  fs.renameSync(tmp, file);        // atomic replace
}

/* ---------------- boot: load snapshot + replay journal ---------------- */
function loadSnapshot() {
  if (!fs.existsSync(SNAP)) return;
  try {
    const s = JSON.parse(fs.readFileSync(SNAP, 'utf8'));
    MEM.rev = s.rev || 0;
    MEM.settings = s.settings || {};
    MEM.users = s.users || {};
    COLLECTIONS.forEach(c => {
      MEM.records[c] = new Map();
      (s.records && s.records[c] ? s.records[c] : []).forEach(r => {
        MEM.records[c].set(String(r.id), r);
      });
    });
  } catch (e) {
    console.error('[storage] snapshot corrupt, starting from journal only:', e.message);
  }
}

function replayJournal() {
  if (!fs.existsSync(JOURNAL)) return;
  const lines = fs.readFileSync(JOURNAL, 'utf8').split('\n');
  let applied = 0;
  for (const line of lines) {
    if (!line.trim()) continue;
    let e;
    try { e = JSON.parse(line); } catch (err) { continue; } // skip torn last line
    applyEntry(e);
    applied++;
  }
  journalCount = applied;
}

function applyEntry(e) {
  if (e.t === 'put') {
    if (!MEM.records[e.c]) MEM.records[e.c] = new Map();
    MEM.records[e.c].set(String(e.id), { id: e.id, data: e.d, rev: e.r, deleted: 0, updated_by: e.by });
    MEM.rev = Math.max(MEM.rev, e.r);
  } else if (e.t === 'del') {
    const m = MEM.records[e.c];
    if (m && m.has(String(e.id))) {
      const rec = m.get(String(e.id));
      rec.deleted = 1; rec.rev = e.r; rec.updated_by = e.by;
    }
    MEM.rev = Math.max(MEM.rev, e.r);
  } else if (e.t === 'set') {
    MEM.settings[e.k] = e.v;
  } else if (e.t === 'user') {
    MEM.users[e.u.username] = e.u;
  }
}

loadSnapshot();
replayJournal();

/* ---------------- compaction ---------------- */
function compact() {
  const records = {};
  COLLECTIONS.forEach(c => {
    records[c] = Array.from(MEM.records[c].values());
  });
  writeAtomic(SNAP, JSON.stringify({
    version: 1,
    savedAt: new Date().toISOString(),
    rev: MEM.rev,
    settings: MEM.settings,
    users: MEM.users,
    records
  }));
  try { fs.writeFileSync(JOURNAL, ''); } catch (e) {}
  journalCount = 0;
}

function maybeCompact() {
  if (journalCount > 2000) compact();
}

/* ---------------- audit ---------------- */
function audit(actor, action, collection, id, before, after) {
  auditCount++;
  try {
    appendLine(AUDIT, {
      seq: auditCount, ts: new Date().toISOString(),
      actor: actor || 'system', action,
      collection: collection || null,
      record_id: id == null ? null : String(id),
      before: before || null, after: after || null
    });
  } catch (e) {}
}
function recentAudit(limit) {
  if (!fs.existsSync(AUDIT)) return [];
  const lines = fs.readFileSync(AUDIT, 'utf8').trim().split('\n').filter(Boolean);
  const out = [];
  for (let i = lines.length - 1; i >= 0 && out.length < Math.min(limit || 100, 2000); i--) {
    try {
      const e = JSON.parse(lines[i]);
      out.push({ seq: e.seq, ts: e.ts, actor: e.actor, action: e.action, collection: e.collection, record_id: e.record_id });
    } catch (err) {}
  }
  return out;
}
if (fs.existsSync(AUDIT)) {
  try { auditCount = fs.readFileSync(AUDIT, 'utf8').trim().split('\n').filter(Boolean).length; } catch (e) {}
}

/* ---------------- core API ---------------- */
function getRev() { return MEM.rev; }
function bumpRev() { return ++MEM.rev; }

function getState() {
  const out = {};
  COLLECTIONS.forEach(c => {
    out[c] = Array.from(MEM.records[c].values())
      .filter(r => !r.deleted)
      .sort((a, b) => {
        const na = parseInt(a.id, 10), nb = parseInt(b.id, 10);
        if (!isNaN(na) && !isNaN(nb)) return na - nb;
        return String(a.id).localeCompare(String(b.id));
      })
      .map(r => r.data);
  });
  return { rev: MEM.rev, data: out };
}

function syncCollection(collection, rows, actor) {
  const rev = bumpRev();
  const m = MEM.records[collection] || (MEM.records[collection] = new Map());
  let inserted = 0, updated = 0, deleted = 0;
  const seen = new Set();
  const batch = [];

  rows.forEach((row, i) => {
    if (row == null || typeof row !== 'object') return;
    if (row.id === undefined || row.id === null || row.id === '') row.id = Date.now() * 1000 + i;
    const id = String(row.id);
    seen.add(id);
    const prev = m.get(id);
    const prevJson = prev ? JSON.stringify(prev.data) : null;
    const json = JSON.stringify(row);
    if (!prev) {
      m.set(id, { id: row.id, data: row, rev, deleted: 0, updated_by: actor });
      batch.push({ t: 'put', c: collection, id: row.id, d: row, r: rev, by: actor });
      inserted++;
      audit(actor, 'insert', collection, id, null, row);
    } else if (prevJson !== json || prev.deleted === 1) {
      m.set(id, { id: row.id, data: row, rev, deleted: 0, updated_by: actor });
      batch.push({ t: 'put', c: collection, id: row.id, d: row, r: rev, by: actor });
      updated++;
      audit(actor, 'update', collection, id, prev.data, row);
    }
  });

  for (const [id, rec] of m) {
    if (!seen.has(id) && !rec.deleted) {
      rec.deleted = 1; rec.rev = rev; rec.updated_by = actor;
      batch.push({ t: 'del', c: collection, id: rec.id, r: rev, by: actor });
      deleted++;
      audit(actor, 'delete', collection, id, rec.data, null);
    }
  }

  if (batch.length) {
    // one fsync for the whole batch = fast bulk imports
    const fd = fs.openSync(JOURNAL, 'a');
    try {
      fs.writeSync(fd, batch.map(b => JSON.stringify(b)).join('\n') + '\n');
      fs.fsyncSync(fd);
    } finally { fs.closeSync(fd); }
    journalCount += batch.length;
    maybeCompact();
  }

  const changed = inserted + updated + deleted;
  return { collection, changed, inserted, updated, deleted, rev };
}

function upsertRecord(collection, row, actor) {
  const rev = bumpRev();
  if (row.id === undefined || row.id === null || row.id === '') row.id = Date.now();
  const m = MEM.records[collection] || (MEM.records[collection] = new Map());
  const id = String(row.id);
  const prev = m.get(id);
  m.set(id, { id: row.id, data: row, rev, deleted: 0, updated_by: actor });
  appendLine(JOURNAL, { t: 'put', c: collection, id: row.id, d: row, r: rev, by: actor });
  journalCount++; maybeCompact();
  audit(actor, prev ? 'update' : 'insert', collection, id, prev ? prev.data : null, row);
  return { rev, record: row };
}

function deleteRecord(collection, id, actor) {
  const rev = bumpRev();
  const m = MEM.records[collection];
  const rec = m ? m.get(String(id)) : null;
  if (rec && !rec.deleted) {
    rec.deleted = 1; rec.rev = rev; rec.updated_by = actor;
    appendLine(JOURNAL, { t: 'del', c: collection, id, r: rev, by: actor });
    journalCount++; maybeCompact();
    audit(actor, 'delete', collection, id, rec.data, null);
  }
  return { rev };
}

function changesSince(sinceRev) {
  const changes = [];
  COLLECTIONS.forEach(c => {
    for (const rec of MEM.records[c].values()) {
      if (rec.rev > sinceRev) {
        changes.push({
          collection: c, id: rec.id, deleted: !!rec.deleted, rev: rec.rev,
          updated_by: rec.updated_by, data: rec.deleted ? null : rec.data
        });
      }
    }
  });
  changes.sort((a, b) => a.rev - b.rev);
  return { rev: MEM.rev, changes: changes.slice(0, 20000) };
}

/* ---------------- settings ---------------- */
function getSetting(key, fallback) {
  return MEM.settings[key] !== undefined ? MEM.settings[key] : fallback;
}
function setSetting(key, value) {
  MEM.settings[key] = value;
  appendLine(JOURNAL, { t: 'set', k: key, v: value });
  journalCount++;
}
function getAllSettings() { return Object.assign({}, MEM.settings); }

/* ---------------- stats / maintenance ---------------- */
function human(b) {
  if (b < 1024) return b + ' B';
  if (b < 1048576) return (b / 1024).toFixed(1) + ' KB';
  if (b < 1073741824) return (b / 1048576).toFixed(1) + ' MB';
  return (b / 1073741824).toFixed(2) + ' GB';
}
function fileSize(f) { try { return fs.statSync(f).size; } catch (e) { return 0; } }

function stats() {
  const collections = {};
  COLLECTIONS.forEach(c => {
    let rows = 0, archived = 0, bytes = 0;
    for (const r of MEM.records[c].values()) {
      if (r.deleted) archived++; else { rows++; bytes += JSON.stringify(r.data).length; }
    }
    collections[c] = { rows, archived, bytes };
  });
  const snapB = fileSize(SNAP), jrnB = fileSize(JOURNAL);
  return {
    rev: MEM.rev, collections, auditEntries: auditCount,
    dbFile: SNAP, dbBytes: snapB + jrnB, walBytes: jrnB,
    dbSize: human(snapB + jrnB), pageSize: 0,
    journalMode: 'json-journal', engine: 'pure-js'
  };
}

function checkpoint() { compact(); }
function vacuum() { compact(); }
function integrityCheck() {
  try {
    if (fs.existsSync(SNAP)) JSON.parse(fs.readFileSync(SNAP, 'utf8'));
    return 'ok';
  } catch (e) { return 'CORRUPT: ' + e.message; }
}

async function backup() {
  compact();
  const dir = path.join(DATA_DIR, 'backups');
  fs.mkdirSync(dir, { recursive: true });
  const name = 'alfa_mrp_' + new Date().toISOString().replace(/[:.]/g, '-') + '.json';
  const dest = path.join(dir, name);
  fs.copyFileSync(SNAP, dest);
  const files = fs.readdirSync(dir).filter(f => f.endsWith('.json')).sort();
  while (files.length > 30) { try { fs.unlinkSync(path.join(dir, files.shift())); } catch (e) {} }
  return { file: name, path: dest, bytes: fileSize(dest) };
}

/* ---------------- seed ---------------- */
function isEmpty() {
  return COLLECTIONS.every(c => Array.from(MEM.records[c].values()).filter(r => !r.deleted).length === 0);
}
function seedAll(seed) {
  COLLECTIONS.forEach(c => {
    if (Array.isArray(seed[c]) && seed[c].length) syncCollection(c, seed[c], 'seed');
  });
  compact();
}

/* ---------------- users / sessions ---------------- */
function hashPassword(pw, salt) {
  salt = salt || crypto.randomBytes(16).toString('hex');
  return { salt, hash: crypto.scryptSync(String(pw), salt, 64).toString('hex') };
}
function createUser(username, password, role, fullName) {
  const { salt, hash } = hashPassword(password);
  const u = { username, pass_hash: hash, salt, role: role || 'operator', full_name: fullName || username, active: 1, created_at: new Date().toISOString() };
  MEM.users[username] = u;
  appendLine(JOURNAL, { t: 'user', u });
  return { username, role: u.role };
}
function authenticate(username, password) {
  const u = MEM.users[username];
  if (!u || !u.active) return null;
  const { hash } = hashPassword(password, u.salt);
  const a = Buffer.from(hash, 'hex'), b = Buffer.from(u.pass_hash, 'hex');
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  return { username: u.username, role: u.role, full_name: u.full_name };
}
function createSession(username, days) {
  const token = crypto.randomBytes(32).toString('hex');
  MEM.sessions[token] = { username, expires: Date.now() + (days || 30) * 86400000 };
  return token;
}
function getSession(token) {
  if (!token) return null;
  const s = MEM.sessions[token];
  if (!s) return null;
  if (s.expires < Date.now()) { delete MEM.sessions[token]; return null; }
  const u = MEM.users[s.username];
  return u && u.active ? { username: u.username, role: u.role, full_name: u.full_name } : null;
}
function destroySession(token) { delete MEM.sessions[token]; }
function listUsers() {
  return Object.values(MEM.users).map(u => ({
    username: u.username, role: u.role, full_name: u.full_name, active: u.active, created_at: u.created_at
  }));
}
function userCount() { return Object.keys(MEM.users).length; }

/* Flush to a clean snapshot on shutdown */
process.on('exit', () => { try { compact(); } catch (e) {} });

module.exports = {
  engine: 'pure-js',
  DB_PATH, DATA_DIR, COLLECTIONS,
  getState, getRev, syncCollection, upsertRecord, deleteRecord, changesSince,
  getSetting, setSetting, getAllSettings,
  stats, backup, checkpoint, integrityCheck, vacuum,
  isEmpty, seedAll, audit, recentAudit,
  createUser, authenticate, createSession, getSession, destroySession, listUsers, userCount,
  human
};
