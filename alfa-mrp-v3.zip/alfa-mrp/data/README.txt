FOLDER DATABASE - PT. ALFA VALVES INDONESIA
===========================================

File alfa_mrp.db di folder ini adalah DATABASE UTAMA aplikasi.
Seluruh data produksi perusahaan tersimpan di sini.

File akan dibuat otomatis saat server pertama kali dijalankan,
lengkap dengan data contoh bawaan.

PENTING:
- Jangan hapus atau pindahkan file .db saat server berjalan
- Salin folder ini ke flashdisk/Drive seminggu sekali sebagai backup
- Backup otomatis tersimpan di subfolder backups/ setiap 6 jam
