// ============================================================
// ALFA VALVES MRP/ERP - VERSI 2.0 STABIL
// 10 Modul Inti, Tanpa Gantt Chart, Dijamin Berfungsi
// ============================================================

// ---------- DATA & STATE ----------
var HR={GATE:3.78,BALL:2.17,GLOBE:3.01,CHECK:2.90,BUTTERFLY:3.56,PLUG:2.50,STRAINER:3.18};
var SK='alfa_v2_stable';
var S={theme:'light',lang:'id',page:'dashboard',selSO:null,calMonth:new Date().getMonth(),calYear:new Date().getFullYear(),tcTab:'consumable',capSearch:'',capType:'',capClass:'',capSource:'',capOpen:{},mrSearch:'',mrStatus:'',mrSO:'',mrItemType:''};

var DATA={
  projects:[
    {id:1,partName:"GATE",size:'10"',ansiClass:150,endConn:"RF",soNo:"011/AVI/0325",customer:"PT. PP PERSERO",qty:13,dueDate:"2026-08-25"},
    {id:2,partName:"BALL",size:'10"',ansiClass:150,endConn:"RF",soNo:"015/AVI/0425",customer:"PT AZYMUTH",qty:2,dueDate:"2026-07-15"},
    {id:3,partName:"BALL",size:'6"',ansiClass:150,endConn:"RF",soNo:"015/AVI/0425",customer:"PT AZYMUTH",qty:4,dueDate:"2026-07-15"},
    {id:4,partName:"CHECK",size:'2"',ansiClass:150,endConn:"RF",soNo:"011/AVI/0325",customer:"PT. PP PERSERO",qty:6,dueDate:"2026-08-25"},
    {id:5,partName:"GLOBE",size:'3"',ansiClass:300,endConn:"RF",soNo:"033/AVI/2025",customer:"PT. FIS",qty:12,dueDate:"2026-11-15"},
    {id:6,partName:"BUTTERFLY",size:'8"',ansiClass:150,endConn:"RF",soNo:"004/TR/AVI",customer:"PT. REKAYASA",qty:8,dueDate:"2026-12-01"},
    {id:7,partName:"STRAINER",size:'6"',ansiClass:150,endConn:"RF",soNo:"020/AVI/TR",customer:"PT. PP PERSERO",qty:15,dueDate:"2026-09-10"},
    {id:8,partName:"GATE",size:'3"',ansiClass:300,endConn:"RF",soNo:"007/TR/AVI",customer:"PT. WIJAYA",qty:10,dueDate:"2027-01-15"}
  ],
  variance:[
    {id:1,soNo:"SO. 015/AVI/0425",process:"Material Arrival",department:"Logistics",planDate:"2026-07-06",actualDate:"2026-07-06",status:"Completed - On Time",variance:0},
    {id:2,soNo:"SO. 015/AVI/0425",process:"Hydrotest",department:"Quality",planDate:"2026-07-06",actualDate:"2026-07-06",status:"Completed - On Time",variance:0},
    {id:3,soNo:"SO. 015/AVI/0425",process:"FAT - TPI",department:"Quality",planDate:"2026-07-14",actualDate:"",status:"Not Done - Overdue",variance:33},
    {id:4,soNo:"SO. 015/AVI/0425",process:"Blasting",department:"Painting",planDate:"2026-07-07",actualDate:"2026-07-07",status:"Completed - On Time",variance:0},
    {id:5,soNo:"SO. 015/AVI/0425",process:"Painting",department:"Painting",planDate:"2026-07-15",actualDate:"",status:"Not Done - Overdue",variance:32},
    {id:6,soNo:"SO. 015/AVI/0425",process:"Final Inspection",department:"Quality",planDate:"2026-07-22",actualDate:"",status:"Not Done - Overdue",variance:25},
    {id:7,soNo:"SO. 015/AVI/0425",process:"Packing",department:"Delivery",planDate:"2026-07-23",actualDate:"",status:"Not Done - Overdue",variance:24}
  ],
  machines:[
    {id:1,name:"Hydraulic Test",brand:"QIXING",capacity:'2"-8"',machineNo:"A1",location:"TESTING",status:"Ready for use",category:"Testing"},
    {id:2,name:"Hydraulic Test",brand:"QIXING DN",capacity:'10"-24"',machineNo:"A3",location:"TESTING",status:"Ready for use",category:"Testing"},
    {id:3,name:"Manual Test",brand:"QIXING",capacity:'½-2"',machineNo:"A5",location:"TESTING",status:"Ready for use",category:"Testing"},
    {id:4,name:"Gas Booster",brand:"HASKEL",capacity:"20000 psi",machineNo:"A6",location:"TESTING",status:"Ready for use",category:"Testing"},
    {id:5,name:"Hydraulic Test",brand:"DY-400",capacity:'8"-16"',machineNo:"A97",location:"TESTING",status:"Ready for use",category:"Testing"},
    {id:6,name:"Lathe Machine",brand:"YANG",capacity:"500x1200",machineNo:"M1",location:"BUILDING II",status:"Ready for use",category:"Machining"},
    {id:7,name:"Milling Machine",brand:"KAO MING",capacity:"2000x900",machineNo:"M2",location:"BUILDING II",status:"Ready for use",category:"Machining"},
    {id:8,name:"Radial Drill",brand:"TAI PIIN",capacity:"50mm",machineNo:"M3",location:"BUILDING II",status:"Ready for use",category:"Machining"},
    {id:9,name:"CNC Lathe",brand:"COLCHESTER",capacity:"250x500",machineNo:"CNC1",location:"BUILDING II",status:"Ready for use",category:"Machining"},
    {id:10,name:"Blasting Booth",brand:"CUSTOM",capacity:"2000x1500",machineNo:"B1",location:"BLASTING",status:"Ready for use",category:"Blasting"},
    {id:11,name:"Painting Booth",brand:"CUSTOM",capacity:"3000x2000",machineNo:"P1",location:"PAINTING",status:"Ready for use",category:"Painting"},
    {id:12,name:"Oven Curing",brand:"CUSTOM",capacity:"2500x1500",machineNo:"O1",location:"PAINTING",status:"Ready for use",category:"Painting"},
    {id:13,name:"Overhead Crane",brand:"HITACHI",capacity:"5 Ton",machineNo:"C1",location:"PROD",status:"Ready for use",category:"Material Handling"},
    {id:14,name:"Forklift",brand:"TOYOTA",capacity:"3 Ton",machineNo:"FL1",location:"WAREHOUSE",status:"Ready for use",category:"Material Handling"},
    {id:15,name:"Air Compressor",brand:"ATLAS",capacity:"150 HP",machineNo:"AC1",location:"UTILITY",status:"Ready for use",category:"Utility"},
    {id:16,name:"Welding Machine",brand:"LINCOLN",capacity:"400A",machineNo:"W1",location:"FAB",status:"Ready for use",category:"Welding"},
    {id:17,name:"Genset",brand:"CUMMINS",capacity:"250KVA",machineNo:"G1",location:"UTILITY",status:"Ready for use",category:"Utility"}
  ],
  consumables:[
    {id:1,description:"Sand Paper 1500",unit:"Ea",safetyStock:10,actualStock:22,status:"STOCK AVAILABLE"},
    {id:2,description:"Sand Paper 320",unit:"Ea",safetyStock:10,actualStock:8,status:"LOW STOCK"},
    {id:3,description:"Flap Wheel Grinder",unit:"Ea",safetyStock:10,actualStock:2,status:"LOW STOCK"},
    {id:4,description:"Disc Grinder 4\"",unit:"Ea",safetyStock:10,actualStock:34,status:"STOCK AVAILABLE"},
    {id:5,description:"Seal Tape 1/2\"",unit:"Ea",safetyStock:60,actualStock:61,status:"STOCK AVAILABLE"},
    {id:6,description:"Brush 2\"",unit:"Ea",safetyStock:5,actualStock:4,status:"LOW STOCK"},
    {id:7,description:"Welding Rod LB-52",unit:"Kg",safetyStock:5,actualStock:0,status:"OUT OF STOCK"},
    {id:8,description:"Blasting Glass",unit:"Ea",safetyStock:5,actualStock:0,status:"OUT OF STOCK"},
    {id:9,description:"O Ring 6mm",unit:"Meter",safetyStock:5,actualStock:0,status:"OUT OF STOCK"},
    {id:10,description:"Grease Burgari",unit:"Kg",safetyStock:5,actualStock:5,status:"STOCK AVAILABLE"},
    {id:11,description:"Duct Tape 2\"",unit:"Ea",safetyStock:25,actualStock:26,status:"STOCK AVAILABLE"},
    {id:12,description:"Long Rag / Duster",unit:"Kg",safetyStock:10,actualStock:15,status:"STOCK AVAILABLE"},
    {id:13,description:"OIL SAE 10W",unit:"Liter",safetyStock:5,actualStock:5,status:"STOCK AVAILABLE"},
    {id:14,description:"Sand Paper 1200",unit:"Ea",safetyStock:10,actualStock:14,status:"STOCK AVAILABLE"},
    {id:15,description:"Sand Paper AA 100",unit:"Meter",safetyStock:20,actualStock:50,status:"STOCK AVAILABLE"}
  ],
  tools:[
    {id:1,name:"Impact Wrench",sizeType:"M117M",merk:"TOKU",location:"ASSY",qty:1,category:"Toolcrib",status:"STOCK AVAILABLE"},
    {id:2,name:"PAS RING 16\"",sizeType:'16"',merk:"EGA",location:"ASSY",qty:1,category:"Toolcrib",status:"STOCK AVAILABLE"},
    {id:3,name:"Kunci Inggris",sizeType:"SEDANG",merk:"-",location:"ASSY",qty:1,category:"Toolcrib",status:"STOCK AVAILABLE"},
    {id:4,name:"Holder DCLNR",sizeType:"External",merk:"Sandvik",location:"Machining",qty:1,category:"CNC",status:"DAMAGED"},
    {id:5,name:"Holder SNR",sizeType:"2525M-12",merk:"Kyocera",location:"Machining",qty:1,category:"CNC",status:"DAMAGED"},
    {id:6,name:"Insert CNMG12408",sizeType:"-",merk:"YG",location:"Machining",qty:5,category:"CNC",status:"STOCK AVAILABLE"},
    {id:7,name:"Insert CM 1125",sizeType:"-",merk:"Sandvik",location:"Machining",qty:3,category:"CNC",status:"STOCK AVAILABLE"},
    {id:8,name:"Holder A40T",sizeType:"Internal",merk:"Sandvik",location:"Machining",qty:1,category:"CNC",status:"DAMAGED"},
    {id:9,name:"Insert DNMG150408",sizeType:"-",merk:"YG",location:"Machining",qty:7,category:"CNC",status:"STOCK AVAILABLE"},
    {id:10,name:"Insert CCMT060204",sizeType:"-",merk:"YG",location:"Machining",qty:0,category:"CNC",status:"NOT AVAILABLE"},
    {id:11,name:"Holder PWLNR",sizeType:"2525M08C",merk:"YG",location:"Machining",qty:1,category:"CNC",status:"STOCK AVAILABLE"},
    {id:12,name:"Insert APMT113504",sizeType:"-",merk:"YG",location:"Machining",qty:5,category:"CNC",status:"STOCK AVAILABLE"},
    {id:13,name:"Holder S16P",sizeType:"SCLCR",merk:"YG",location:"Machining",qty:1,category:"CNC",status:"NOT AVAILABLE"},
    {id:14,name:"Kunci Ketok",sizeType:"RING 41",merk:"ELORA",location:"ASSY",qty:1,category:"Toolcrib",status:"STOCK AVAILABLE"},
    {id:15,name:"Kunci L",sizeType:'3/8"',merk:"CR-V",location:"ASSY",qty:1,category:"Toolcrib",status:"STOCK AVAILABLE"}
  ],
  capacity:[],
  schedules:[
    {id:1,date:"2026-07-20",event:"2.BLASTING & PRIMER - SO 030",shift:"SHIFT 1"},
    {id:2,date:"2026-07-21",event:"3.SECOND & TOP COAT - SO 030",shift:"SHIFT 1"},
    {id:3,date:"2026-07-22",event:"1.HYDRO - SO 002 - 4 NO'S",shift:"SHIFT 2"},
    {id:4,date:"2026-07-22",event:"1.HYDRO - SO 002 - Balance",shift:"SHIFT 2"},
    {id:5,date:"2026-07-23",event:"2.BLASTING & PRIMER - SO 002",shift:"SHIFT 1"},
    {id:6,date:"2026-07-25",event:"1.HYDRO - SO 012 - 8 NO'S",shift:"SHIFT 1"},
    {id:7,date:"2026-07-27",event:"1.HYDRO - SO 004 - 76 NO'S",shift:"SHIFT 2"},
    {id:8,date:"2026-07-28",event:"1.HYDRO - SO 004 - 76 NO'S",shift:"SHIFT 2"},
    {id:9,date:"2026-07-30",event:"1.HYDRO INSPECTION - SO 002",shift:"SHIFT 1"}
  ],
  mrlist:[
    {id:1,mrNo:"MR-2026-001",reqDate:"2026-08-02",soNo:"SO. 015",typeValve:'BALL 10" 150#',valveQty:2,machine:"A97",itemType:"consumable",itemId:9,itemName:"O Ring 6mm",unit:"Meter",qtyRequest:50,needDate:"2026-08-20",status:"Pending",supplier:"PT Sinar Karet",remark:"Untuk seat & body seal",receivedDate:"",receivedQty:0},
    {id:2,mrNo:"MR-2026-001",reqDate:"2026-08-02",soNo:"SO. 015",typeValve:'BALL 10" 150#',valveQty:2,machine:"A97",itemType:"consumable",itemId:8,itemName:"Blasting Glass",unit:"Ea",qtyRequest:25,needDate:"2026-08-20",status:"Ordered",supplier:"CV Abrasive Jaya",remark:"PO 0812/AVI",receivedDate:"",receivedQty:0},
    {id:3,mrNo:"MR-2026-001",reqDate:"2026-08-02",soNo:"SO. 015",typeValve:'BALL 10" 150#',valveQty:2,machine:"A97",itemType:"consumable",itemId:13,itemName:"OIL SAE 10W",unit:"Liter",qtyRequest:5,needDate:"2026-08-22",status:"Pending",supplier:"-",remark:"Rotary oil hydrotest",receivedDate:"",receivedQty:0},
    {id:4,mrNo:"MR-2026-002",reqDate:"2026-08-04",soNo:"SO. 015",typeValve:'BALL 6" 150#',valveQty:4,machine:"A1/A2",itemType:"consumable",itemId:10,itemName:"Grease Burgari",unit:"Kg",qtyRequest:5,needDate:"2026-08-21",status:"Pending",supplier:"-",remark:"",receivedDate:"",receivedQty:0},
    {id:5,mrNo:"MR-2026-002",reqDate:"2026-08-04",soNo:"SO. 015",typeValve:'BALL 6" 150#',valveQty:4,machine:"A1/A2",itemType:"consumable",itemId:2,itemName:"Sand Paper 320",unit:"Ea",qtyRequest:20,needDate:"2026-08-19",status:"Ordered",supplier:"Toko Maju",remark:"PO 0815/AVI",receivedDate:"",receivedQty:0},
    {id:6,mrNo:"MR-2026-003",reqDate:"2026-08-05",soNo:"SO. 015",typeValve:'BALL 4" 150#',valveQty:2,machine:"A1/A2",itemType:"consumable",itemId:5,itemName:"Seal Tape 1/2\"",unit:"Ea",qtyRequest:20,needDate:"2026-08-23",status:"Pending",supplier:"-",remark:"",receivedDate:"",receivedQty:0},
    {id:7,mrNo:"MR-2026-004",reqDate:"2026-07-28",soNo:"SO. 011",typeValve:'GATE 10" 150#',valveQty:13,machine:"A3",itemType:"consumable",itemId:11,itemName:"Duct Tape 2\"",unit:"Ea",qtyRequest:10,needDate:"2026-08-10",status:"Received",supplier:"Toko Maju",remark:"Masking painting",receivedDate:"2026-08-08",receivedQty:10},
    {id:8,mrNo:"MR-2026-004",reqDate:"2026-07-28",soNo:"SO. 011",typeValve:'GATE 10" 150#',valveQty:13,machine:"A3",itemType:"consumable",itemId:3,itemName:"Flap Wheel Grinder",unit:"Ea",qtyRequest:12,needDate:"2026-08-18",status:"Ordered",supplier:"CV Teknik Abadi",remark:"PO 0801/AVI",receivedDate:"",receivedQty:0},
    {id:9,mrNo:"MR-2026-005",reqDate:"2026-08-06",soNo:"SO. 011",typeValve:'GATE 20" 150#',valveQty:3,machine:"A3",itemType:"consumable",itemId:7,itemName:"Welding Rod LB-52",unit:"Kg",qtyRequest:25,needDate:"2026-08-18",status:"Pending",supplier:"-",remark:"Stok habis - urgent",receivedDate:"",receivedQty:0},
    {id:10,mrNo:"MR-2026-006",reqDate:"2026-08-07",soNo:"SO. 033",typeValve:'GLOBE 3" 300#',valveQty:12,machine:"A1",itemType:"tools",itemId:6,itemName:"Insert CNMG12408",unit:"Ea",qtyRequest:10,needDate:"2026-09-01",status:"Pending",supplier:"YG Indonesia",remark:"",receivedDate:"",receivedQty:0},
    {id:11,mrNo:"MR-2026-007",reqDate:"2026-08-08",soNo:"SO. 004",typeValve:'BUTTERFLY 8" 150#',valveQty:8,machine:"A2",itemType:"tools",itemId:4,itemName:"Holder DCLNR",unit:"Ea",qtyRequest:1,needDate:"2026-08-30",status:"Ordered",supplier:"Sandvik Dist.",remark:"Ganti yang damaged",receivedDate:"",receivedQty:0},
    {id:12,mrNo:"MR-2026-008",reqDate:"2026-08-10",soNo:"SO. 020",typeValve:'STRAINER 6" 150#',valveQty:15,machine:"CNC1",itemType:"tools",itemId:10,itemName:"Insert CCMT060204",unit:"Ea",qtyRequest:10,needDate:"2026-08-28",status:"Pending",supplier:"YG Indonesia",remark:"Stok 0",receivedDate:"",receivedQty:0}
  ],
  receipts:[
    {id:1,date:"2026-08-08",mrNo:"MR-2026-004",itemType:"consumable",itemId:11,itemName:"Duct Tape 2\"",unit:"Ea",qty:10,soNo:"SO. 011",pic:"Warehouse",note:"Diterima lengkap",stockBefore:16,stockAfter:26}
  ],
  salesOrders:[]
};

// Generate capacity data
// ---------- MASTER LIST CAPACITY ----------
var CAP_TYPES=["BALL VALVES","GATE VALVES","GLOBE VALVES","CHECK VALVES","BUTTERFLY VALVES","STRAINER"];
var CAP_SIZES=['1/2"','3/4"','1"','1-1/2"','2"','3"','4"','6"','8"','10"','12"','16"','20"','24"'];
var CAP_CLASSES=[150,300,600];
var CAP_SIZE_NOM={'1/2"':0.5,'3/4"':0.75,'1"':1,'1-1/2"':1.5,'2"':2,'3"':3,'4"':4,'6"':6,'8"':8,'10"':10,'12"':12,'16"':16,'20"':20,'24"':24};
var CAP_TYPE_F={"BALL VALVES":1.00,"GATE VALVES":1.15,"GLOBE VALVES":1.10,"CHECK VALVES":0.85,"BUTTERFLY VALVES":0.80,"STRAINER":0.75};
var CAP_CLASS_F={150:1.00,300:1.18,600:1.40};

// Generate capacity data (semua Type Valve x Size x Class)
(function(){
  var id=1;
  CAP_TYPES.forEach(function(t){
    CAP_SIZES.forEach(function(sz){
      CAP_CLASSES.forEach(function(cl){
        var nom=CAP_SIZE_NOM[sz]||1, tf=CAP_TYPE_F[t]||1, cf=CAP_CLASS_F[cl]||1;
        var te=Math.round((10+nom*1.9)*tf*cf);
        var bl=Math.round((8+nom*1.40)*(cf*0.5+0.5));
        var pa=Math.round((18+nom*2.20)*(cf*0.4+0.6));
        var hd=Math.round(10+nom*0.8);
        var tot=te+bl+pa;
        DATA.capacity.push({id:id++,typeValve:t,size:sz,ansiClass:cl+"#",testingMin:te,blastingMin:bl,paintingMin:pa,handlingMin:hd,totalProcessMin:tot,totalHours:parseFloat(((tot+hd)/60).toFixed(2)),source:(cl===150&&nom<=8)?"Aktual":"Estimasi"});
      });
    });
  });
})();
DATA.capacityDefault=JSON.parse(JSON.stringify(DATA.capacity));
function capRecalc(r){r.totalProcessMin=(+r.testingMin||0)+(+r.blastingMin||0)+(+r.paintingMin||0);r.totalHours=parseFloat(((r.totalProcessMin+(+r.handlingMin||0))/60).toFixed(2));return r;}

// ---------- STORAGE ----------
function save(opts){try{localStorage.setItem(SK,JSON.stringify({projects:DATA.projects,variance:DATA.variance,schedules:DATA.schedules,capacity:DATA.capacity,mrlist:DATA.mrlist,receipts:DATA.receipts,consumables:DATA.consumables,tools:DATA.tools,machines:DATA.machines,theme:S.theme,lang:S.lang}));}catch(e){}if(window.ALFA&&ALFA.push){ALFA.push(opts);}}
function load(){var d=null;if(window.__ALFA_BOOT){d=window.__ALFA_BOOT;}else{try{var raw=localStorage.getItem(SK);if(raw)d=JSON.parse(raw);}catch(e){}}if(!d)return false;return applyServerData(d);}function applyServerData(d){if(!d)return false;if(d.projects&&d.projects.length)DATA.projects=d.projects;if(d.variance&&d.variance.length)DATA.variance=d.variance;if(d.schedules&&d.schedules.length)DATA.schedules=d.schedules;if(d.capacity&&d.capacity.length)DATA.capacity=d.capacity;if(d.mrlist)DATA.mrlist=d.mrlist;if(d.receipts)DATA.receipts=d.receipts;if(d.consumables&&d.consumables.length)DATA.consumables=d.consumables;if(d.tools&&d.tools.length)DATA.tools=d.tools;if(d.machines&&d.machines.length)DATA.machines=d.machines;if(d.theme)S.theme=d.theme;if(d.lang)S.lang=d.lang;return true;}window.applyServerData=applyServerData;

// ---------- HELPERS ----------
function toast(m,t){var x=document.getElementById('toast');x.textContent=m;x.className='toast '+(t||'info');setTimeout(function(){x.classList.add('show');},10);setTimeout(function(){x.classList.remove('show');},2500);}
function openModal(){document.getElementById('modalBox').classList.add('active');}
function closeModal(){document.getElementById('modalBox').classList.remove('active');}
function pd(s){var p=String(s).split('-');return new Date(+p[0],+p[1]-1,+p[2]);}
function fd(v){if(!v)return'';if(typeof v==='number'){var d=XLSX.SSF.parse_date_code(v);return d?d.y+'-'+String(d.m).padStart(2,'0')+'-'+String(d.d).padStart(2,'0'):'';}if(v instanceof Date)return v.toISOString().split('T')[0];return String(v);}
function toggleTheme(){S.theme=S.theme==='light'?'dark':'light';if(S.theme==='dark'){document.documentElement.setAttribute('data-theme','dark');document.getElementById('themeBtn').textContent='☾';}else{document.documentElement.removeAttribute('data-theme');document.getElementById('themeBtn').textContent='☀';}save();renderCurrentPage();}
function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');document.getElementById('mobileOverlay').classList.toggle('active');}
function setLang(l){S.lang=l;save();document.getElementById('langID').classList.toggle('active',l==='id');document.getElementById('langEN').classList.toggle('active',l==='en');renderNav();renderCurrentPage();}
function genSO(){var m={};DATA.projects.forEach(function(p){var k=p.soNo||'Unknown';if(!m[k])m[k]={soNo:k,customer:p.customer||'-',items:0,qty:0,dueDates:[],valveTypes:{}};m[k].items++;m[k].qty+=(p.qty||0);if(p.dueDate)m[k].dueDates.push(p.dueDate);var vt=p.partName+' '+p.size;m[k].valveTypes[vt]=(m[k].valveTypes[vt]||0)+(p.qty||0);});DATA.salesOrders=Object.keys(m).map(function(k){var so=m[k],hrs=0;DATA.projects.forEach(function(p){if((p.soNo||'Unknown')===k)hrs+=(p.qty||0)*(HR[p.partName]||2.85);});hrs=parseFloat(hrs.toFixed(2));var days=parseFloat((hrs/8).toFixed(2));var prog=30;if(so.dueDates.length>0){var sd=so.dueDates.sort();var e=pd(sd[0]);e.setHours(0,0,0,0);var l=pd(sd[sd.length-1]);l.setHours(0,0,0,0);var t=new Date();t.setHours(0,0,0,0);var tot=l-e;prog=tot>0?Math.min(100,Math.max(0,Math.round(((t-e)/tot)*100))):(t>=l?100:30);}return{soNo:so.soNo,customer:so.customer,items:so.items,qty:so.qty,hours:hrs,days:days,progress:prog,dueDates:so.dueDates,valveTypes:so.valveTypes};}).sort(function(a,b){return a.soNo.localeCompare(b.soNo);});}

// ---------- NAVIGASI ----------
var NAV_ITEMS=[
  {id:'dashboard',label:'Dashboard',sec:'Overview',icon:'<rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/>'},
  {id:'projects',label:'Detail Project',sec:'Sales & Production',icon:'<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>'},
  {id:'sales',label:'Sales Orders',sec:'Sales & Production',icon:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>'},
  {id:'variance',label:'Variance',sec:'Sales & Production',icon:'<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/>'},
  {id:'machining',label:'Machining',sec:'Capacity & Schedule',icon:'<rect x="2" y="6" width="20" height="12" rx="2"/>'},
  {id:'capacity',label:'Capacity',sec:'Capacity & Schedule',icon:'<path d="M3 3v18h18"/>'},
  {id:'schedule',label:'Schedule',sec:'Capacity & Schedule',icon:'<rect x="3" y="4" width="18" height="18" rx="2"/>'},
  {id:'mrlist',label:'MR List',sec:'Material & Tools',icon:'<path d="M9 11H5a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7a2 2 0 0 0-2-2h-4"/>'},
  {id:'tools',label:'Tools & Cons.',sec:'Material & Tools',icon:'<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>'},
  {id:'reports',label:'Reports',sec:'Output',icon:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>'}
];

var PAGE_TITLES={
  dashboard:['Dashboard','Production Overview'],
  projects:['Detail Project','Sumber data utama'],
  sales:['Sales Orders','Otomatis dari Detail Project'],
  variance:['Variance Analysis','Plan vs Actual'],
  machining:['Machining','Daftar mesin & peralatan'],
  capacity:['Capacity Summary','Standard waktu proses per Type Valve'],
  schedule:['Schedule Calendar','Kalender jadwal produksi'],
  mrlist:['MR List','Material Request — terhubung Tools & Cons.'],
  tools:['Tools & Consumable','Data stok'],
  reports:['Reports','Download laporan Excel']
};

function renderNav(){var nav=document.getElementById('navMenu');nav.innerHTML='';var curSec='';NAV_ITEMS.forEach(function(item){if(item.sec!==curSec){curSec=item.sec;var sec=document.createElement('div');sec.style.cssText='padding:14px 16px 4px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--muted);opacity:.7;';sec.textContent=curSec;nav.appendChild(sec);}var nv=document.createElement('div');nv.className='nav-item'+(S.page===item.id?' active':'');nv.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">'+item.icon+'</svg><span>'+item.label+'</span>';nv.onclick=function(){go(item.id);};nav.appendChild(nv);});}

function go(page){S.page=page;document.querySelectorAll('.nav-item').forEach(function(n){n.classList.remove('active');});var idx=NAV_ITEMS.findIndex(function(i){return i.id===page;});document.querySelectorAll('.nav-item')[idx].classList.add('active');var tt=PAGE_TITLES[page];document.getElementById('pageTitle').textContent=tt[0];document.getElementById('pageSubtitle').textContent=tt[1];if(window.innerWidth<=768){document.getElementById('sidebar').classList.remove('open');document.getElementById('mobileOverlay').classList.remove('active');}renderCurrentPage();}

// ---------- RENDER CURRENT PAGE ----------
function renderCurrentPage(){genSO();var container=document.getElementById('pagesContainer');container.innerHTML='';switch(S.page){case'dashboard':renderDashboard(container);break;case'projects':renderProjects(container);break;case'sales':renderSales(container);break;case'variance':renderVariance(container);break;case'machining':renderMachining(container);break;case'capacity':renderCapacity(container);break;case'schedule':renderSchedule(container);break;case'mrlist':renderMRList(container);break;case'tools':renderTools(container);break;case'reports':renderReports(container);break;}}

// ============================================================
// 1. DASHBOARD
// ============================================================
function renderDashboard(c){var tq=DATA.salesOrders.reduce(function(s,so){return s+so.qty;},0);var ot=DATA.variance.filter(function(v){return v.status&&v.status.toLowerCase().includes('on time');}).length;var ov=DATA.variance.filter(function(v){return v.status&&(v.status.toLowerCase().includes('overdue')||v.status.toLowerCase().includes('late'));}).length;var rm=DATA.machines.filter(function(m){return m.status&&m.status.toLowerCase().includes('ready');}).length;var lc=DATA.consumables.filter(function(c){return c.status==='LOW STOCK'||c.status==='OUT OF STOCK';}).length;var lt=DATA.tools.filter(function(t){return t.status==='NOT AVAILABLE'||t.status==='DAMAGED';}).length;c.innerHTML='<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:18px;"><div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">Total SO</span><div style="font-size:26px;font-weight:700;margin-top:4px;">'+DATA.salesOrders.length+'</div><div style="font-size:10px;color:var(--success);">● dari Detail Project</div></div><div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">Total Qty</span><div style="font-size:26px;font-weight:700;margin-top:4px;">'+tq.toLocaleString()+'</div><div style="font-size:10px;color:var(--muted);">pieces</div></div><div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">On Time</span><div style="font-size:26px;font-weight:700;color:var(--success);margin-top:4px;">'+ot+'</div><div style="font-size:10px;color:var(--muted);">● dari Variance</div></div><div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">Overdue</span><div style="font-size:26px;font-weight:700;color:var(--danger);margin-top:4px;">'+ov+'</div><div style="font-size:10px;color:var(--muted);">● dari Variance</div></div><div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">Low / Out Stock</span><div style="font-size:26px;font-weight:700;color:var(--danger);margin-top:4px;">'+(lc+lt)+'</div><div style="font-size:10px;color:var(--muted);">● Cons. + Tools</div></div><div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">Mesin Ready</span><div style="font-size:26px;font-weight:700;color:var(--accent2);margin-top:4px;">'+rm+'</div><div style="font-size:10px;color:var(--muted);">of '+DATA.machines.length+' total</div></div></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:18px;"><div class="chart-container"><h3 style="font-size:13px;font-weight:600;margin:0 0 10px 0;">Estimasi Durasi per Type Valve</h3><div id="chart1" style="height:250px;width:100%;"></div></div><div class="chart-container"><h3 style="font-size:13px;font-weight:600;margin:0 0 10px 0;">On Time vs Overdue (Variance)</h3><div id="chart2" style="height:250px;width:100%;"></div></div></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;"><div class="table-container"><div style="padding:12px 16px;border-bottom:1px solid var(--border);"><h3 style="font-size:12.5px;font-weight:600;margin:0;">⚠ SO Akan Overdue / Lewat</h3></div><table class="data-table"><thead><tr><th>SO. NO</th><th>Customer</th><th>Qty</th><th>Due Date</th><th>Status</th></tr></thead><tbody id="tbOverdue"></tbody></table></div><div class="table-container"><div style="padding:12px 16px;border-bottom:1px solid var(--border);"><h3 style="font-size:12.5px;font-weight:600;margin:0;">⚠ Cons. & Tools Out of Stock</h3></div><table class="data-table"><thead><tr><th>Item</th><th>Type</th><th>Stock</th><th>Status</th></tr></thead><tbody id="tbOutstock"></tbody></table></div></div>';setTimeout(function(){renderDashCharts();renderDashTables();},50);}

function renderDashCharts(){if(!document.getElementById('chart1')||!document.getElementById('chart2'))return;if(typeof echarts==='undefined'){['chart1','chart2'].forEach(function(id){var e=document.getElementById(id);if(e)e.innerHTML='<div style="display:flex;align-items:center;justify-content:center;height:100%;min-height:220px;color:var(--muted);font-size:12px;text-align:center;padding:20px;">Grafik butuh koneksi internet (ECharts CDN).<br>Buka file ini langsung di browser untuk melihat chart.</div>';});return;}var st=getComputedStyle(document.documentElement);var ac=st.getPropertyValue('--accent').trim()||'#c47046';var ac2=st.getPropertyValue('--accent2').trim()||'#2563eb';var mu=st.getPropertyValue('--muted').trim()||'#6b6b6b';var bd=st.getPropertyValue('--border').trim()||'rgba(0,0,0,.08)';var cd=st.getPropertyValue('--card').trim()||'#fff';var sc=st.getPropertyValue('--success').trim()||'#16a34a';var dc=st.getPropertyValue('--danger').trim()||'#dc2626';var ts={};DATA.projects.forEach(function(p){var tp=p.partName||'OTHER';if(!ts[tp])ts[tp]={qty:0};ts[tp].qty+=(p.qty||0);});var types=Object.keys(ts).sort();var qa=types.map(function(tp){return ts[tp].qty;});var ha=types.map(function(tp){return parseFloat((ts[tp].qty*(HR[tp]||2.85)).toFixed(2));});if(window.__ch1)window.__ch1.dispose();var c1=window.__ch1=echarts.init(document.getElementById('chart1'));c1.setOption({backgroundColor:'transparent',tooltip:{trigger:'axis',backgroundColor:cd,borderColor:bd},legend:{data:['Duration (Hours)','Quantity'],textStyle:{color:mu},top:0},grid:{left:'3%',right:'4%',bottom:'3%',containLabel:true},xAxis:{type:'category',data:types,axisLabel:{color:mu}},yAxis:[{type:'value',name:'Hrs',axisLabel:{color:mu},splitLine:{lineStyle:{color:bd}}},{type:'value',name:'Qty',axisLabel:{color:mu},splitLine:{show:false}}],series:[{name:'Duration (Hours)',type:'bar',data:ha,itemStyle:{borderRadius:[6,6,0,0],color:ac},barWidth:'30%'},{name:'Quantity',type:'line',yAxisIndex:1,data:qa,smooth:true,lineStyle:{color:ac2,width:3},itemStyle:{color:ac2}}]});var ot=DATA.variance.filter(function(v){return v.status&&v.status.toLowerCase().includes('on time');}).length;var ov=DATA.variance.filter(function(v){return v.status&&(v.status.toLowerCase().includes('overdue')||v.status.toLowerCase().includes('late'));}).length;var ip=Math.max(0,DATA.variance.length-ot-ov);if(window.__ch2)window.__ch2.dispose();var c2=window.__ch2=echarts.init(document.getElementById('chart2'));c2.setOption({backgroundColor:'transparent',tooltip:{trigger:'item',backgroundColor:cd,borderColor:bd},legend:{orient:'vertical',right:'3%',top:'center',textStyle:{color:mu,fontSize:11}},series:[{type:'pie',radius:['45%','70%'],center:['35%','50%'],itemStyle:{borderRadius:6,borderColor:cd,borderWidth:2},label:{show:true,position:'outside',formatter:'{b}: {c} ({d}%)',color:mu,fontSize:11},data:[{value:ot,name:'On Time',itemStyle:{color:sc}},{value:ov,name:'Overdue',itemStyle:{color:dc}},{value:ip,name:'Other',itemStyle:{color:ac2}}]}]});}

function renderDashTables(){var tb1=document.getElementById('tbOverdue');var tb2=document.getElementById('tbOutstock');if(!tb1||!tb2)return;var now=new Date();now.setHours(0,0,0,0);var list=[];DATA.salesOrders.forEach(function(so){if(!so.dueDates||so.dueDates.length===0)return;var due=pd(so.dueDates.sort()[so.dueDates.length-1]);due.setHours(0,0,0,0);var dd=Math.ceil((due-now)/(1000*60*60*24));if(dd<=30){var sc,sc2;if(dd<0){sc='⚠ Overdue';sc2='status-danger';}else{sc='⏰ Segera';sc2='status-warning';}list.push({so:so,dd:dd,sc:sc,sc2:sc2});}});list.sort(function(a,b){return a.dd-b.dd;});if(list.length===0){tb1.innerHTML='<tr><td colspan="5" style="text-align:center;padding:24px;color:var(--success);">✓ Aman</td></tr>';}else{list.slice(0,8).forEach(function(it){var tr=document.createElement('tr');tr.innerHTML='<td style="font-weight:600;color:var(--accent);">'+it.so.soNo+'</td><td>'+it.so.customer+'</td><td>'+it.so.qty.toLocaleString()+'</td><td>'+it.so.dueDates.sort()[it.so.dueDates.length-1]+'</td><td><span class="status-pill '+it.sc2+'">'+it.sc+'</span></td>';tb1.appendChild(tr);});}var items=[];DATA.consumables.forEach(function(c){if(c.status==='OUT OF STOCK')items.push({name:c.description,type:'Consumable',stock:c.actualStock,status:c.status,sc:'status-danger'});});DATA.tools.forEach(function(t){if(t.status==='NOT AVAILABLE')items.push({name:t.name,type:'Tools',stock:t.qty,status:t.status,sc:'status-danger'});});if(items.length===0){tb2.innerHTML='<tr><td colspan="4" style="text-align:center;padding:24px;color:var(--success);">✓ Aman</td></tr>';}else{items.slice(0,10).forEach(function(it){var tr=document.createElement('tr');tr.innerHTML='<td style="font-weight:500;">'+it.name+'</td><td>'+it.type+'</td><td><strong style="color:var(--danger);">'+it.stock+'</strong></td><td><span class="status-pill '+it.sc+'">'+it.status+'</span></td>';tb2.appendChild(tr);});}}

// ============================================================
// 2. DETAIL PROJECT
// ============================================================
function renderProjects(c){c.innerHTML='<div style="margin-bottom:16px;"><h2 class="section-title">SALES & PRODUCTION DATA</h2><p class="section-subtitle">Klik SO untuk melihat rincian type valve</p><div id="soResumeFilter" style="display:none;margin-bottom:10px;"><span class="filter-info">🔍 Filtered by: <strong id="filteredSOName">-</strong> <button class="btn btn-secondary btn-sm" onclick="clearSOFilter()" style="margin-left:8px;padding:2px 8px;font-size:10px;">✕ Clear</button></span></div><div class="so-resume-grid" id="soResumeGrid"></div></div><div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;flex-wrap:wrap;gap:8px;"><div><h2 class="section-title">Detail Project</h2><p class="section-subtitle">Sumber data utama</p></div><div class="action-bar"><input type="text" class="search-input" id="projSearch" placeholder="Cari..." oninput="filterProjects()"><button class="btn btn-info btn-sm" onclick="exportProjExcel()">Export</button><button class="btn btn-secondary btn-sm" onclick="document.getElementById(\'impProj\').click()">Import</button><input type="file" id="impProj" accept=".xlsx,.xls" style="display:none" onchange="importProjExcel(event)"><button class="btn btn-danger btn-sm" onclick="resetProjects()">Reset</button><button class="btn btn-primary" onclick="openProjModal()">+ Add</button></div></div><div class="table-container" style="overflow-x:auto;"><table class="data-table"><thead><tr><th>Part</th><th>Size</th><th>Class</th><th>SO. NO</th><th>Customer</th><th>Qty</th><th>Due Date</th><th>Action</th></tr></thead><tbody id="projTable"></tbody></table></div>';renderSOResume();filterProjects();}

function renderSOResume(){var grid=document.getElementById('soResumeGrid');if(!grid)return;grid.innerHTML='';DATA.salesOrders.forEach(function(so){var vtk=Object.keys(so.valveTypes);var vtt=vtk.slice(0,2).join(', ')+(vtk.length>2?' +'+(vtk.length-2):'');var card=document.createElement('div');card.className='so-resume-card'+(S.selSO===so.soNo?' active':'');card.onclick=function(){S.selSO=S.selSO===so.soNo?null:so.soNo;var fi=document.getElementById('soResumeFilter');if(S.selSO){fi.style.display='inline-flex';document.getElementById('filteredSOName').textContent=S.selSO;}else{fi.style.display='none';}renderSOResume();filterProjects();};card.innerHTML='<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px;"><strong style="color:var(--accent);font-size:13px;">'+so.soNo+'</strong><span class="badge" style="background:var(--accent-soft);color:var(--accent);">'+so.items+' items</span></div><div style="font-size:11.5px;margin-bottom:4px;font-weight:500;">'+so.customer+'</div><div style="font-size:10.5px;color:var(--muted);margin-bottom:6px;">'+vtt+'</div><div style="display:flex;justify-content:space-between;font-size:11px;"><span style="color:var(--accent2);font-weight:600;">'+so.qty.toLocaleString()+' pcs</span><span style="color:var(--muted);">'+so.hours.toLocaleString()+' hrs</span></div>';grid.appendChild(card);});}

function clearSOFilter(){S.selSO=null;document.getElementById('soResumeFilter').style.display='none';renderSOResume();filterProjects();}

function filterProjects(){var s=document.getElementById('projSearch').value.toLowerCase();var data=DATA.projects.filter(function(p){return(p.partName||'').toLowerCase().includes(s)||(p.soNo||'').toLowerCase().includes(s)||(p.customer||'').toLowerCase().includes(s);});if(S.selSO)data=data.filter(function(p){return p.soNo===S.selSO;});var tb=document.getElementById('projTable');if(!tb)return;tb.innerHTML='';if(data.length===0){tb.innerHTML='<tr><td colspan="8" style="text-align:center;padding:24px;color:var(--muted);">Tidak ada data</td></tr>';return;}data.slice(0,20).forEach(function(p){var tr=document.createElement('tr');tr.innerHTML='<td style="font-weight:600;">'+p.partName+'</td><td>'+p.size+'</td><td>'+p.ansiClass+'</td><td style="color:var(--accent);font-weight:500;">'+p.soNo+'</td><td>'+(p.customer||'-')+'</td><td><span class="badge" style="background:var(--accent-soft);color:var(--accent);">'+p.qty+'</span></td><td>'+(p.dueDate||'-')+'</td><td><button class="btn btn-secondary btn-sm" onclick="editProject('+p.id+')" style="margin-right:3px;">Edit</button><button class="btn btn-danger btn-sm" onclick="delProject('+p.id+')">Del</button></td>';tb.appendChild(tr);});}

function openProjModal(id){document.getElementById('modalTitle').textContent=id?'Edit Project':'Add Project';var html='<form id="projForm"><input type="hidden" id="editProjId" value="'+(id||'')+'"><div class="form-row"><div class="form-group"><label>Part Name *</label><select id="p_part"><option>GATE</option><option>BALL</option><option>GLOBE</option><option>CHECK</option><option>BUTTERFLY</option><option>PLUG</option><option>STRAINER</option></select></div><div class="form-group"><label>Size *</label><input type="text" id="p_size" required></div></div><div class="form-row"><div class="form-group"><label>ANSI Class *</label><input type="number" id="p_class" required></div><div class="form-group"><label>End Conn</label><select id="p_end"><option>RF</option><option>FF</option><option>SW</option><option>BW</option></select></div></div><div class="form-row"><div class="form-group"><label>SO. NO *</label><input type="text" id="p_so" required></div><div class="form-group"><label>Qty *</label><input type="number" id="p_qty" required></div></div><div class="form-group"><label>Customer *</label><input type="text" id="p_cust" required></div><div class="form-row"><div class="form-group"><label>Order Date</label><input type="date" id="p_odate"></div><div class="form-group"><label>Due Date</label><input type="date" id="p_ddate"></div></div></form>';document.getElementById('modalBody').innerHTML=html;document.getElementById('modalFooter').innerHTML='<button class="btn btn-secondary" onclick="closeModal()">Cancel</button><button class="btn btn-primary" onclick="saveProject()">Save</button>';if(id){var p=DATA.projects.find(function(x){return x.id===id;});if(p){document.getElementById('p_part').value=p.partName||'GATE';document.getElementById('p_size').value=p.size||'';document.getElementById('p_class').value=p.ansiClass||'';document.getElementById('p_end').value=p.endConn||'RF';document.getElementById('p_so').value=p.soNo||'';document.getElementById('p_qty').value=p.qty||'';document.getElementById('p_cust').value=p.customer||'';document.getElementById('p_odate').value=p.orderDate||'';document.getElementById('p_ddate').value=p.dueDate||'';}}openModal();}

function editProject(id){openProjModal(id);}

function delProject(id){if(confirm('Hapus project?')){DATA.projects=DATA.projects.filter(function(p){return p.id!==id;});save();renderCurrentPage();toast('Dihapus!','success');}}

function saveProject(){var pn=document.getElementById('p_part').value,sz=document.getElementById('p_size').value,cl=document.getElementById('p_class').value,so=document.getElementById('p_so').value,qt=document.getElementById('p_qty').value,cu=document.getElementById('p_cust').value;if(!pn||!sz||!cl||!so||!qt||!cu){toast('Lengkapi field!','error');return;}var pr={partName:pn,size:sz,ansiClass:parseInt(cl),endConn:document.getElementById('p_end').value,soNo:so,qty:parseInt(qt),customer:cu,orderDate:document.getElementById('p_odate').value,dueDate:document.getElementById('p_ddate').value};var ei=document.getElementById('editProjId').value;if(ei){var ix=DATA.projects.findIndex(function(p){return p.id===parseInt(ei);});if(ix!==-1){pr.id=parseInt(ei);DATA.projects[ix]=pr;}toast('Diperbarui!','success');}else{pr.id=Date.now();DATA.projects.unshift(pr);toast('Ditambahkan!','success');}save();closeModal();renderCurrentPage();}

function resetProjects(){if(confirm('Reset ke default?')){DATA.projects=JSON.parse(JSON.stringify([{id:1,partName:"GATE",size:'10"',ansiClass:150,endConn:"RF",soNo:"011/AVI/0325",customer:"PT. PP PERSERO",qty:13,dueDate:"2026-08-25"},{id:2,partName:"BALL",size:'10"',ansiClass:150,endConn:"RF",soNo:"015/AVI/0425",customer:"PT AZYMUTH",qty:2,dueDate:"2026-07-15"},{id:3,partName:"BALL",size:'6"',ansiClass:150,endConn:"RF",soNo:"015/AVI/0425",customer:"PT AZYMUTH",qty:4,dueDate:"2026-07-15"},{id:4,partName:"CHECK",size:'2"',ansiClass:150,endConn:"RF",soNo:"011/AVI/0325",customer:"PT. PP PERSERO",qty:6,dueDate:"2026-08-25"},{id:5,partName:"GLOBE",size:'3"',ansiClass:300,endConn:"RF",soNo:"033/AVI/2025",customer:"PT. FIS",qty:12,dueDate:"2026-11-15"},{id:6,partName:"BUTTERFLY",size:'8"',ansiClass:150,endConn:"RF",soNo:"004/TR/AVI",customer:"PT. REKAYASA",qty:8,dueDate:"2026-12-01"},{id:7,partName:"STRAINER",size:'6"',ansiClass:150,endConn:"RF",soNo:"020/AVI/TR",customer:"PT. PP PERSERO",qty:15,dueDate:"2026-09-10"},{id:8,partName:"GATE",size:'3"',ansiClass:300,endConn:"RF",soNo:"007/TR/AVI",customer:"PT. WIJAYA",qty:10,dueDate:"2027-01-15"}]));S.selSO=null;save();renderCurrentPage();toast('Direset!','success');}}

function exportProjExcel(){try{var data=DATA.projects.map(function(p){return{'Part Name':p.partName,'Size':p.size,'ANSI Class':p.ansiClass,'SO. NO':p.soNo,'Customer':p.customer,'QTY':p.qty,'Due Date':p.dueDate};});var wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(data),'Projects');XLSX.writeFile(wb,'ALFA_Projects.xlsx');toast('Export berhasil!','success');}catch(e){toast('Gagal!','error');}}

function importProjExcel(ev){var f=ev.target.files[0];if(!f)return;var r=new FileReader();r.onload=function(e){try{var wb=XLSX.read(new Uint8Array(e.target.result),{type:'array'});var js=XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]);if(js.length===0){toast('File kosong!','error');return;}if(confirm('Ditemukan '+js.length+' data. Ganti?')){DATA.projects=js.map(function(r,i){return{id:Date.now()+i,partName:r['Part Name']||'',size:r['Size']||'',ansiClass:r['ANSI Class']||0,soNo:r['SO. NO']||'',customer:r['Customer']||'',qty:parseInt(r['QTY']||0),dueDate:fd(r['Due Date']||'')};});save();renderCurrentPage();toast('Import berhasil!','success');}}catch(e){toast('Gagal baca!','error');}};r.readAsArrayBuffer(f);ev.target.value='';}

// ============================================================
// 3. SALES ORDERS
// ============================================================
function renderSales(c){c.innerHTML='<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;flex-wrap:wrap;gap:8px;"><div><h2 class="section-title">Sales Orders</h2><p class="section-subtitle">Otomatis dari Detail Project</p></div><div class="action-bar"><input type="text" class="search-input" id="soSearch" placeholder="Cari..." oninput="filterSO()"></div></div><div class="table-container" style="overflow-x:auto;"><table class="data-table"><thead><tr><th>SO. NO</th><th>Customer</th><th>Items</th><th>Qty</th><th>Hours</th><th>Days</th><th>Progress</th></tr></thead><tbody id="soTable"></tbody></table></div>';filterSO();}

function filterSO(){var s=document.getElementById('soSearch').value.toLowerCase();var data=DATA.salesOrders.filter(function(so){return so.soNo.toLowerCase().includes(s)||so.customer.toLowerCase().includes(s);});var tb=document.getElementById('soTable');if(!tb)return;tb.innerHTML='';data.forEach(function(so){var pc=so.progress>=80?'var(--success)':so.progress>=40?'var(--warning)':'var(--danger)';var tr=document.createElement('tr');tr.innerHTML='<td style="font-weight:600;color:var(--accent);">'+so.soNo+'</td><td>'+so.customer+'</td><td>'+so.items+'</td><td>'+so.qty.toLocaleString()+'</td><td>'+so.hours.toLocaleString()+'</td><td>'+so.days.toLocaleString()+'</td><td style="min-width:130px;"><div style="display:flex;align-items:center;gap:6px;"><div style="flex:1;height:6px;background:var(--border);border-radius:3px;overflow:hidden;"><div style="width:'+so.progress+'%;height:100%;background:'+pc+';"></div></div><span style="font-size:11px;font-weight:600;color:'+pc+';">'+so.progress+'%</span></div></td>';tb.appendChild(tr);});}

// ============================================================
// 4. VARIANCE
// ============================================================
function renderVariance(c){var ot=DATA.variance.filter(function(v){return v.status&&v.status.toLowerCase().includes('on time');}).length;var ov=DATA.variance.filter(function(v){return v.status&&(v.status.toLowerCase().includes('overdue')||v.status.toLowerCase().includes('late'));}).length;var tot=DATA.variance.length;var comp=DATA.variance.filter(function(v){return v.status&&v.status.toLowerCase().includes('completed');});var avg=comp.length>0?comp.reduce(function(s,v){return s+(v.variance||0);},0)/comp.length:0;c.innerHTML='<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;flex-wrap:wrap;gap:8px;"><div><h2 class="section-title">Variance Analysis</h2><p class="section-subtitle">Plan vs Actual</p></div><div class="action-bar"><input type="text" class="search-input" id="varSearch" placeholder="Cari..." oninput="filterVariance()"><button class="btn btn-info btn-sm" onclick="exportVarExcel()">Export</button><button class="btn btn-secondary btn-sm" onclick="document.getElementById(\'impVar\').click()">Import</button><input type="file" id="impVar" accept=".xlsx,.xls" style="display:none" onchange="importVarExcel(event)"><button class="btn btn-danger btn-sm" onclick="resetVariance()">Reset</button><button class="btn btn-primary" onclick="openVarModal()">+ Add</button></div></div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:12px;margin-bottom:18px;"><div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">Total</span><div style="font-size:24px;font-weight:700;margin-top:4px;">'+tot+'</div></div><div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">On Time</span><div style="font-size:24px;font-weight:700;color:var(--success);margin-top:4px;">'+ot+'</div><div style="font-size:10px;color:var(--muted);">'+(tot>0?Math.round((ot/tot)*100):0)+'%</div></div><div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">Overdue</span><div style="font-size:24px;font-weight:700;color:var(--danger);margin-top:4px;">'+ov+'</div><div style="font-size:10px;color:var(--muted);">'+(tot>0?Math.round((ov/tot)*100):0)+'%</div></div><div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">Avg Var</span><div style="font-size:24px;font-weight:700;color:var(--warning);margin-top:4px;">'+avg.toFixed(1)+'</div><div style="font-size:10px;color:var(--muted);">days</div></div></div><div class="table-container" style="overflow-x:auto;"><table class="data-table"><thead><tr><th>SO. NO</th><th>Process</th><th>Dept</th><th>Plan</th><th>Actual</th><th>Status</th><th>Var</th><th>Action</th></tr></thead><tbody id="varTable"></tbody></table></div>';filterVariance();}

function filterVariance(){var s=document.getElementById('varSearch').value.toLowerCase();var data=DATA.variance.filter(function(v){return(v.soNo||'').toLowerCase().includes(s)||(v.process||'').toLowerCase().includes(s);});var tb=document.getElementById('varTable');if(!tb)return;tb.innerHTML='';data.forEach(function(v){var sc=v.status&&v.status.toLowerCase().includes('on time')?'status-success':v.status&&v.status.toLowerCase().includes('overdue')?'status-danger':'status-warning';var tr=document.createElement('tr');tr.innerHTML='<td style="color:var(--accent);font-weight:500;">'+v.soNo+'</td><td>'+v.process+'</td><td>'+v.department+'</td><td>'+v.planDate+'</td><td>'+(v.actualDate||'-')+'</td><td><span class="status-pill '+sc+'">'+v.status+'</span></td><td>'+(v.variance>0?'+'+v.variance+'d':(v.variance<0?v.variance+'d':'-'))+'</td><td><button class="btn btn-secondary btn-sm" onclick="editVar('+v.id+')" style="margin-right:3px;">Edit</button><button class="btn btn-danger btn-sm" onclick="delVar('+v.id+')">Del</button></td>';tb.appendChild(tr);});}

function openVarModal(id){document.getElementById('modalTitle').textContent=id?'Edit Variance':'Add Variance';var html='<form id="varForm"><input type="hidden" id="editVarId" value="'+(id||'')+'"><div class="form-group"><label>SO. NO *</label><input type="text" id="v_so" required></div><div class="form-group"><label>Process *</label><input type="text" id="v_proc" required></div><div class="form-group"><label>Department *</label><select id="v_dept" required><option>Logistics</option><option>Quality</option><option>Production</option><option>Painting</option><option>Delivery</option></select></div><div class="form-row"><div class="form-group"><label>Plan Date *</label><input type="date" id="v_pdate" required></div><div class="form-group"><label>Actual Date</label><input type="date" id="v_adate"></div></div><div class="form-row"><div class="form-group"><label>Status *</label><select id="v_status" required><option>Completed - On Time</option><option>Completed - Late</option><option>Not Done - Overdue</option><option>Not Done - In Plan</option><option>In Progress</option></select></div><div class="form-group"><label>Variance *</label><input type="number" id="v_var" required></div></div></form>';document.getElementById('modalBody').innerHTML=html;document.getElementById('modalFooter').innerHTML='<button class="btn btn-secondary" onclick="closeModal()">Cancel</button><button class="btn btn-primary" onclick="saveVariance()">Save</button>';if(id){var v=DATA.variance.find(function(x){return x.id===id;});if(v){document.getElementById('v_so').value=v.soNo;document.getElementById('v_proc').value=v.process;document.getElementById('v_dept').value=v.department;document.getElementById('v_pdate').value=v.planDate;document.getElementById('v_adate').value=v.actualDate||'';document.getElementById('v_status').value=v.status;document.getElementById('v_var').value=v.variance;}}openModal();}

function editVar(id){openVarModal(id);}

function delVar(id){if(confirm('Hapus variance?')){DATA.variance=DATA.variance.filter(function(v){return v.id!==id;});save();renderCurrentPage();toast('Dihapus!','success');}}

function saveVariance(){var so=document.getElementById('v_so').value,pr=document.getElementById('v_proc').value,dp=document.getElementById('v_dept').value,pd=document.getElementById('v_pdate').value,st=document.getElementById('v_status').value,va=document.getElementById('v_var').value;if(!so||!pr||!dp||!pd||!st||va===''){toast('Lengkapi field!','error');return;}var v={soNo:so,process:pr,department:dp,planDate:pd,actualDate:document.getElementById('v_adate').value,status:st,variance:parseInt(va)};var ei=document.getElementById('editVarId').value;if(ei){var ix=DATA.variance.findIndex(function(x){return x.id===parseInt(ei);});if(ix!==-1){v.id=parseInt(ei);DATA.variance[ix]=v;}toast('Diperbarui!','success');}else{v.id=Date.now();DATA.variance.unshift(v);toast('Ditambahkan!','success');}save();closeModal();renderCurrentPage();}

function resetVariance(){if(confirm('Reset ke default?')){DATA.variance=JSON.parse(JSON.stringify([{id:1,soNo:"SO. 015/AVI/0425",process:"Material Arrival",department:"Logistics",planDate:"2026-07-06",actualDate:"2026-07-06",status:"Completed - On Time",variance:0},{id:2,soNo:"SO. 015/AVI/0425",process:"Hydrotest",department:"Quality",planDate:"2026-07-06",actualDate:"2026-07-06",status:"Completed - On Time",variance:0},{id:3,soNo:"SO. 015/AVI/0425",process:"FAT - TPI",department:"Quality",planDate:"2026-07-14",actualDate:"",status:"Not Done - Overdue",variance:33},{id:4,soNo:"SO. 015/AVI/0425",process:"Blasting",department:"Painting",planDate:"2026-07-07",actualDate:"2026-07-07",status:"Completed - On Time",variance:0},{id:5,soNo:"SO. 015/AVI/0425",process:"Painting",department:"Painting",planDate:"2026-07-15",actualDate:"",status:"Not Done - Overdue",variance:32},{id:6,soNo:"SO. 015/AVI/0425",process:"Final Inspection",department:"Quality",planDate:"2026-07-22",actualDate:"",status:"Not Done - Overdue",variance:25},{id:7,soNo:"SO. 015/AVI/0425",process:"Packing",department:"Delivery",planDate:"2026-07-23",actualDate:"",status:"Not Done - Overdue",variance:24}]));save();renderCurrentPage();toast('Direset!','success');}}

function exportVarExcel(){try{var data=DATA.variance.map(function(v){return{'SO. NO':v.soNo,'Process':v.process,'Department':v.department,'Plan Date':v.planDate,'Actual Date':v.actualDate,'Status':v.status,'Variance':v.variance};});var wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(data),'Variance');XLSX.writeFile(wb,'ALFA_Variance.xlsx');toast('Export berhasil!','success');}catch(e){toast('Gagal!','error');}}

function importVarExcel(ev){var f=ev.target.files[0];if(!f)return;var r=new FileReader();r.onload=function(e){try{var wb=XLSX.read(new Uint8Array(e.target.result),{type:'array'});var js=XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]);if(js.length===0){toast('File kosong!','error');return;}if(confirm('Ditemukan '+js.length+' data. Ganti?')){DATA.variance=js.map(function(r,i){return{id:Date.now()+i,soNo:r['SO. NO']||'',process:r['Process']||'',department:r['Department']||'',planDate:fd(r['Plan Date']||''),actualDate:fd(r['Actual Date']||''),status:r['Status']||'Completed - On Time',variance:parseInt(r['Variance']||0)||0};});save();renderCurrentPage();toast('Import berhasil!','success');}}catch(e){toast('Gagal baca!','error');}};r.readAsArrayBuffer(f);ev.target.value='';}

// ============================================================
// 5. MACHINING
// ============================================================
function renderMachining(c){var ready=DATA.machines.filter(function(m){return m.status&&m.status.toLowerCase().includes('ready');}).length;var cats=[...new Set(DATA.machines.map(function(m){return m.category||'Other';}))];var test=DATA.machines.filter(function(m){return m.category==='Testing';}).length;c.innerHTML='<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;flex-wrap:wrap;gap:8px;"><div><h2 class="section-title">Machining</h2><p class="section-subtitle">Daftar mesin & peralatan</p></div><div class="action-bar"><input type="text" class="search-input" id="machSearch" placeholder="Cari..." oninput="filterMachining()"><select class="search-input" id="machCat" style="max-width:160px;" onchange="filterMachining()"><option value="">All Categories</option></select></div></div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:18px;"><div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">Total Mesin</span><div style="font-size:24px;font-weight:700;margin-top:4px;">'+DATA.machines.length+'</div></div><div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">Ready</span><div style="font-size:24px;font-weight:700;color:var(--success);margin-top:4px;">'+ready+'</div></div><div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">Kategori</span><div style="font-size:24px;font-weight:700;color:var(--accent2);margin-top:4px;">'+cats.length+'</div></div><div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">Testing Area</span><div style="font-size:24px;font-weight:700;color:var(--warning);margin-top:4px;">'+test+'</div></div></div><div class="table-container" style="overflow-x:auto;"><table class="data-table"><thead><tr><th>No</th><th>Machine Name</th><th>Brand</th><th>Capacity</th><th>No</th><th>Location</th><th>Category</th><th>Status</th></tr></thead><tbody id="machTable"></tbody></table></div>';var sel=document.getElementById('machCat');cats.sort().forEach(function(c){var o=document.createElement('option');o.value=c;o.textContent=c;sel.appendChild(o);});filterMachining();}

function filterMachining(){var s=document.getElementById('machSearch').value.toLowerCase();var c=document.getElementById('machCat').value;var data=DATA.machines.filter(function(m){var ms=!s||(m.name||'').toLowerCase().includes(s)||(m.machineNo||'').toLowerCase().includes(s);var mc=!c||m.category===c;return ms&&mc;});var tb=document.getElementById('machTable');if(!tb)return;tb.innerHTML='';data.forEach(function(m,i){var sc=m.status&&m.status.toLowerCase().includes('ready')?'status-success':'status-warning';var tr=document.createElement('tr');tr.innerHTML='<td>'+(i+1)+'</td><td style="font-weight:500;">'+m.name+'</td><td>'+m.brand+'</td><td>'+m.capacity+'</td><td><span class="badge" style="background:var(--accent2-soft);color:var(--accent2);">'+m.machineNo+'</span></td><td>'+m.location+'</td><td>'+m.category+'</td><td><span class="status-pill '+sc+'">'+m.status+'</span></td>';tb.appendChild(tr);});}

// ============================================================
// 6. CAPACITY
// ============================================================
// ============================================================
// 6. CAPACITY  (grouped per Type Valve + CRUD)
// ============================================================
function esc(v){return String(v==null?'':v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function capFiltered(){
  var s=(S.capSearch||'').toLowerCase(), t=S.capType||'', cl=S.capClass||'', src=S.capSource||'';
  return DATA.capacity.filter(function(c){
    var ms=!s||(c.typeValve||'').toLowerCase().indexOf(s)>=0||(c.size||'').toLowerCase().indexOf(s)>=0||String(c.ansiClass||'').toLowerCase().indexOf(s)>=0;
    return ms&&(!t||c.typeValve===t)&&(!cl||String(c.ansiClass)===cl)&&(!src||c.source===src);
  });
}
function renderCapacity(c){
  var all=DATA.capacity;
  var avg=function(arr,k){return arr.length?arr.reduce(function(s,x){return s+(+x[k]||0);},0)/arr.length:0;};
  var types=CAP_TYPES.filter(function(t){return all.some(function(x){return x.typeValve===t;});});
  var extra=[...new Set(all.map(function(x){return x.typeValve;}))].filter(function(t){return types.indexOf(t)<0;}).sort();
  types=types.concat(extra);
  var classes=[...new Set(all.map(function(x){return String(x.ansiClass);}))].sort(function(a,b){return parseInt(a)-parseInt(b);});
  var kpi=function(lbl,val,sub,col){return '<div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">'+lbl+'</span><div style="font-size:24px;font-weight:700;margin-top:4px;'+(col?'color:'+col+';':'')+'">'+val+'</div>'+(sub?'<div style="font-size:10px;color:var(--muted);">'+sub+'</div>':'')+'</div>';};
  var h='<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;flex-wrap:wrap;gap:8px;">'+
    '<div><h2 class="section-title">Capacity Summary</h2><p class="section-subtitle">Standard waktu proses per Type Valve — Size — Class</p></div>'+
    '<div class="action-bar">'+
      '<input type="text" class="search-input" id="capSearch" placeholder="Cari type / size / class..." value="'+esc(S.capSearch||'')+'" oninput="capOnFilter()">'+
      '<select class="search-input" id="capType" style="max-width:170px;" onchange="capOnFilter()"><option value="">Semua Type</option>'+types.map(function(t){return '<option value="'+esc(t)+'"'+(S.capType===t?' selected':'')+'>'+esc(t)+'</option>';}).join('')+'</select>'+
      '<select class="search-input" id="capClass" style="max-width:110px;" onchange="capOnFilter()"><option value="">Semua Class</option>'+classes.map(function(x){return '<option value="'+esc(x)+'"'+(S.capClass===x?' selected':'')+'>'+esc(x)+'</option>';}).join('')+'</select>'+
      '<select class="search-input" id="capSource" style="max-width:120px;" onchange="capOnFilter()"><option value="">Semua Source</option><option value="Aktual"'+(S.capSource==='Aktual'?' selected':'')+'>Aktual</option><option value="Estimasi"'+(S.capSource==='Estimasi'?' selected':'')+'>Estimasi</option></select>'+
      '<button class="btn btn-primary btn-sm" onclick="openCapModal()">+ Add</button>'+
      '<button class="btn btn-secondary btn-sm" onclick="capToggleAll(1)">Expand All</button>'+
      '<button class="btn btn-secondary btn-sm" onclick="capToggleAll(0)">Collapse All</button>'+
      '<button class="btn btn-secondary btn-sm" onclick="exportCapExcel()">↓ Excel</button>'+
      '<button class="btn btn-danger btn-sm" onclick="resetCapacity()">Reset</button>'+
    '</div></div>'+
    '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:16px;">'+
      kpi('Total Records',all.length,types.length+' type valve','')+
      kpi('Avg Testing',avg(all,'testingMin').toFixed(1),'menit','var(--accent2)')+
      kpi('Avg Blasting',avg(all,'blastingMin').toFixed(1),'menit','var(--warning)')+
      kpi('Avg Painting',avg(all,'paintingMin').toFixed(1),'menit','#7c3aed')+
      kpi('Avg Total Hours',avg(all,'totalHours').toFixed(2),'jam / unit','var(--success)')+
    '</div>'+
    '<div id="capGroups"></div>';
  c.innerHTML=h;
  renderCapGroups();
}
function capOnFilter(){
  S.capSearch=document.getElementById('capSearch').value;
  S.capType=document.getElementById('capType').value;
  S.capClass=document.getElementById('capClass').value;
  S.capSource=document.getElementById('capSource').value;
  renderCapGroups();
}
function capToggleAll(open){
  S.capOpen=S.capOpen||{};
  var types=[...new Set(DATA.capacity.map(function(x){return x.typeValve;}))];
  types.forEach(function(t){S.capOpen[t]=!!open;});
  renderCapGroups();
}
function capToggle(t){S.capOpen=S.capOpen||{};S.capOpen[t]=!S.capOpen[t];renderCapGroups();}
function renderCapGroups(){
  var box=document.getElementById('capGroups');if(!box)return;
  S.capOpen=S.capOpen||{};
  var data=capFiltered();
  if(!data.length){box.innerHTML='<div class="table-container" style="padding:34px;text-align:center;color:var(--muted);font-size:13px;">Tidak ada data yang cocok dengan filter.</div>';return;}
  var order=CAP_TYPES.slice();
  var groups={};
  data.forEach(function(r){(groups[r.typeValve]=groups[r.typeValve]||[]).push(r);});
  var keys=Object.keys(groups).sort(function(a,b){var ia=order.indexOf(a),ib=order.indexOf(b);if(ia<0)ia=99;if(ib<0)ib=99;return ia-ib||a.localeCompare(b);});
  var szOrder=CAP_SIZES.slice();
  var html='<div style="font-size:11.5px;color:var(--muted);margin-bottom:10px;">Menampilkan <strong style="color:var(--text);">'+data.length+'</strong> dari '+DATA.capacity.length+' record • '+keys.length+' Type Valve</div>';
  keys.forEach(function(t){
    var rows=groups[t].slice().sort(function(a,b){
      var ia=szOrder.indexOf(a.size),ib=szOrder.indexOf(b.size);
      if(ia<0)ia=99;if(ib<0)ib=99;
      return ia-ib||parseInt(a.ansiClass)-parseInt(b.ansiClass);
    });
    var tot=rows.reduce(function(s,x){return s+(+x.totalHours||0);},0);
    var avgH=rows.length?tot/rows.length:0;
    var mn=Math.min.apply(null,rows.map(function(x){return +x.totalHours||0;}));
    var mx=Math.max.apply(null,rows.map(function(x){return +x.totalHours||0;}));
    var open=S.capOpen[t]!==false;
    html+='<div class="table-container" style="margin-bottom:12px;">'+
      '<div onclick="capToggle(\''+t.replace(/'/g,"\\'")+'\')" style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:11px 14px;cursor:pointer;background:var(--accent-soft);flex-wrap:wrap;">'+
        '<div style="display:flex;align-items:center;gap:9px;"><span style="font-size:11px;color:var(--accent);width:12px;display:inline-block;">'+(open?'▼':'▶')+'</span>'+
        '<strong style="font-size:13px;color:var(--accent);">'+esc(t)+'</strong>'+
        '<span class="badge" style="background:var(--card);color:var(--muted);">'+rows.length+' record</span></div>'+
        '<div style="display:flex;gap:14px;font-size:10.5px;color:var(--muted);flex-wrap:wrap;">'+
          '<span>Avg <strong style="color:var(--text);">'+avgH.toFixed(2)+'</strong> jam</span>'+
          '<span>Min <strong style="color:var(--success);">'+mn.toFixed(2)+'</strong></span>'+
          '<span>Max <strong style="color:var(--danger);">'+mx.toFixed(2)+'</strong></span>'+
        '</div></div>'+
      (open?'<div style="overflow-x:auto;"><table class="data-table"><thead><tr><th>Size</th><th>Class</th><th>Testing</th><th>Blasting</th><th>Painting</th><th>Handling</th><th>Total Proses</th><th>Jam/Unit</th><th>Source</th><th style="text-align:right;">Aksi</th></tr></thead><tbody>'+
        rows.map(function(r){
          var sr=r.source==='Aktual'?'status-success':'status-info';
          return '<tr><td style="font-weight:600;">'+esc(r.size)+'</td><td>'+esc(r.ansiClass)+'</td><td>'+r.testingMin+'</td><td>'+r.blastingMin+'</td><td>'+r.paintingMin+'</td><td>'+(r.handlingMin||0)+'</td><td style="font-weight:500;">'+r.totalProcessMin+' mnt</td><td style="font-weight:700;color:var(--accent);">'+(+r.totalHours).toFixed(2)+'</td><td><span class="status-pill '+sr+'">'+esc(r.source)+'</span></td>'+
          '<td style="text-align:right;white-space:nowrap;"><button class="btn btn-info btn-sm" onclick="openCapModal('+r.id+')">Edit</button> <button class="btn btn-danger btn-sm" onclick="delCap('+r.id+')">Hapus</button></td></tr>';
        }).join('')+'</tbody></table></div>':'')+
    '</div>';
  });
  box.innerHTML=html;
}
function openCapModal(id){
  var r=id?DATA.capacity.find(function(x){return x.id===id;}):null;
  document.getElementById('modalTitle').textContent=r?'Edit Capacity':'Add Capacity';
  var types=[...new Set(CAP_TYPES.concat(DATA.capacity.map(function(x){return x.typeValve;})))];
  var sizes=[...new Set(CAP_SIZES.concat(DATA.capacity.map(function(x){return x.size;})))];
  document.getElementById('modalBody').innerHTML='<form id="capForm" onsubmit="return false;"><input type="hidden" id="c_id" value="'+(r?r.id:'')+'">'+
    '<div class="form-row"><div class="form-group"><label>Type Valve *</label><input list="capTypeList" id="c_type" value="'+esc(r?r.typeValve:'')+'" placeholder="BALL VALVES"><datalist id="capTypeList">'+types.map(function(t){return '<option value="'+esc(t)+'">';}).join('')+'</datalist></div>'+
    '<div class="form-group"><label>Size *</label><input list="capSizeList" id="c_size" value="'+esc(r?r.size:'')+'" placeholder=\'6&quot;\'><datalist id="capSizeList">'+sizes.map(function(t){return '<option value="'+esc(t)+'">';}).join('')+'</datalist></div></div>'+
    '<div class="form-row"><div class="form-group"><label>ANSI Class *</label><select id="c_class"><option value="150#">150#</option><option value="300#">300#</option><option value="600#">600#</option><option value="900#">900#</option></select></div>'+
    '<div class="form-group"><label>Source</label><select id="c_src"><option value="Aktual">Aktual</option><option value="Estimasi">Estimasi</option></select></div></div>'+
    '<div class="form-row"><div class="form-group"><label>Testing (menit)</label><input type="number" id="c_test" min="0" value="'+(r?r.testingMin:0)+'" oninput="capPreview()"></div>'+
    '<div class="form-group"><label>Blasting (menit)</label><input type="number" id="c_blast" min="0" value="'+(r?r.blastingMin:0)+'" oninput="capPreview()"></div></div>'+
    '<div class="form-row"><div class="form-group"><label>Painting (menit)</label><input type="number" id="c_paint" min="0" value="'+(r?r.paintingMin:0)+'" oninput="capPreview()"></div>'+
    '<div class="form-group"><label>Handling (menit)</label><input type="number" id="c_hand" min="0" value="'+(r?(r.handlingMin||0):0)+'" oninput="capPreview()"></div></div>'+
    '<div style="padding:10px 12px;background:var(--accent-soft);border-radius:8px;font-size:12px;">Total proses: <strong id="c_prev_min">0</strong> menit &nbsp;•&nbsp; <strong id="c_prev_hr">0.00</strong> jam/unit</div></form>';
  document.getElementById('modalFooter').innerHTML='<button class="btn btn-secondary" onclick="closeModal()">Batal</button><button class="btn btn-primary" onclick="saveCap()">Simpan</button>';
  if(r)document.getElementById('c_class').value=r.ansiClass;
  if(r)document.getElementById('c_src').value=r.source;
  capPreview();openModal();
}
function capPreview(){
  var t=+document.getElementById('c_test').value||0,b=+document.getElementById('c_blast').value||0,p=+document.getElementById('c_paint').value||0,h=+document.getElementById('c_hand').value||0;
  document.getElementById('c_prev_min').textContent=(t+b+p);
  document.getElementById('c_prev_hr').textContent=((t+b+p+h)/60).toFixed(2);
}
function saveCap(){
  var id=document.getElementById('c_id').value;
  var o={typeValve:(document.getElementById('c_type').value||'').trim().toUpperCase(),size:(document.getElementById('c_size').value||'').trim(),ansiClass:document.getElementById('c_class').value,source:document.getElementById('c_src').value,testingMin:+document.getElementById('c_test').value||0,blastingMin:+document.getElementById('c_blast').value||0,paintingMin:+document.getElementById('c_paint').value||0,handlingMin:+document.getElementById('c_hand').value||0};
  if(!o.typeValve||!o.size){toast('Type Valve & Size wajib diisi!','error');return;}
  capRecalc(o);
  if(id){var r=DATA.capacity.find(function(x){return x.id===+id;});Object.assign(r,o);toast('Capacity diperbarui','success');}
  else{o.id=DATA.capacity.reduce(function(m,x){return Math.max(m,x.id);},0)+1;DATA.capacity.push(o);S.capOpen=S.capOpen||{};S.capOpen[o.typeValve]=true;toast('Capacity ditambahkan','success');}
  save();closeModal();renderCurrentPage();
}
function delCap(id){
  var r=DATA.capacity.find(function(x){return x.id===id;});if(!r)return;
  if(confirm('Hapus capacity '+r.typeValve+' '+r.size+' '+r.ansiClass+'?')){DATA.capacity=DATA.capacity.filter(function(x){return x.id!==id;});save();renderCurrentPage();toast('Dihapus','success');}
}
function resetCapacity(){
  if(confirm('Reset semua data Capacity ke default?')){DATA.capacity=JSON.parse(JSON.stringify(DATA.capacityDefault));save();renderCurrentPage();toast('Capacity direset','success');}
}
function exportCapExcel(){
  if(typeof XLSX==='undefined'){toast('Export butuh koneksi internet','error');return;}
  try{
    var rows=capFiltered().map(function(c){return{'Type Valve':c.typeValve,'Size':c.size,'ANSI Class':c.ansiClass,'Testing (min)':c.testingMin,'Blasting (min)':c.blastingMin,'Painting (min)':c.paintingMin,'Handling (min)':c.handlingMin||0,'Total Process (min)':c.totalProcessMin,'Total Hours':c.totalHours,'Source':c.source};});
    var wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(rows),'Capacity');
    XLSX.writeFile(wb,'Capacity_Summary.xlsx');toast('Excel diunduh','success');
  }catch(e){toast('Gagal export','error');}
}

// ============================================================
// 7. SCHEDULE
// ============================================================
function renderSchedule(c){c.innerHTML='<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;flex-wrap:wrap;gap:8px;"><div><h2 class="section-title">Schedule Calendar</h2><p class="section-subtitle">Kalender jadwal produksi</p></div><div class="action-bar"><button class="btn btn-secondary btn-sm" onclick="changeMonth(-1)">←</button><span id="monthLabel" style="font-weight:600;font-size:13px;min-width:130px;text-align:center;">July 2026</span><button class="btn btn-secondary btn-sm" onclick="changeMonth(1)">→</button><button class="btn btn-info btn-sm" onclick="exportSchedExcel()">Export</button><button class="btn btn-secondary btn-sm" onclick="document.getElementById(\'impSched\').click()">Import</button><input type="file" id="impSched" accept=".xlsx,.xls" style="display:none" onchange="importSchedExcel(event)"><button class="btn btn-danger btn-sm" onclick="resetSchedule()">Reset</button><button class="btn btn-primary" onclick="openSchedModal()">+ Add</button></div></div><div style="display:grid;grid-template-columns:2fr 1fr;gap:12px;"><div class="chart-container"><div class="calendar-grid" id="calGrid"></div></div><div class="table-container"><div style="padding:12px 16px;border-bottom:1px solid var(--border);"><h3 style="font-size:12.5px;font-weight:600;margin:0;">Daftar Jadwal</h3></div><div style="max-height:460px;overflow-y:auto;"><table class="data-table"><thead><tr><th>Date</th><th>Event</th><th>Shift</th><th>Act</th></tr></thead><tbody id="schedTable"></tbody></table></div></div></div>';renderCal();renderSchedTable();}

function changeMonth(d){S.calMonth+=d;if(S.calMonth>11){S.calMonth=0;S.calYear++;}if(S.calMonth<0){S.calMonth=11;S.calYear--;}renderCal();}

function renderCal(){var grid=document.getElementById('calGrid');if(!grid)return;grid.innerHTML='';var mn=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];var dn=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];var ml=document.getElementById('monthLabel');if(ml)ml.textContent=mn[S.calMonth]+' '+S.calYear;dn.forEach(function(d,i){var h=document.createElement('div');h.className='cal-day-header';h.textContent=d;if(i>=5)h.style.color='var(--danger)';grid.appendChild(h);});var fd=new Date(S.calYear,S.calMonth,1);var ld=new Date(S.calYear,S.calMonth+1,0);var sd=(fd.getDay()+6)%7;var today=new Date();today.setHours(0,0,0,0);for(var i=0;i<sd;i++){var e=document.createElement('div');e.className='cal-day';e.style.visibility='hidden';grid.appendChild(e);}for(var d=1;d<=ld.getDate();d++){var cd=new Date(S.calYear,S.calMonth,d);cd.setHours(0,0,0,0);var isWe=cd.getDay()===0||cd.getDay()===6;var isTd=cd.getTime()===today.getTime();var ds=S.calYear+'-'+String(S.calMonth+1).padStart(2,'0')+'-'+String(d).padStart(2,'0');var evs=DATA.schedules.filter(function(s){return s.date===ds;});var el=document.createElement('div');el.className='cal-day'+(isWe?' weekend':'')+(isTd?' today':'');el.innerHTML='<div class="cal-day-num">'+d+'</div>';evs.slice(0,3).forEach(function(e){el.innerHTML+='<div class="cal-event" title="'+e.event+'">'+e.event.substring(0,22)+'</div>';});if(evs.length>3)el.innerHTML+='<div style="font-size:9px;color:var(--muted);margin-top:2px;">+'+(evs.length-3)+'</div>';grid.appendChild(el);}}

function renderSchedTable(){var tb=document.getElementById('schedTable');if(!tb)return;tb.innerHTML='';var sd=[...DATA.schedules].sort(function(a,b){return a.date.localeCompare(b.date);});sd.slice(0,30).forEach(function(s){var tr=document.createElement('tr');tr.innerHTML='<td style="font-size:11px;">'+s.date+'</td><td style="font-size:11px;max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">'+s.event+'</td><td><span class="badge" style="background:var(--accent-soft);color:var(--accent);font-size:10px;">'+s.shift+'</span></td><td><button class="btn btn-danger btn-sm" onclick="delSched('+s.id+')">Del</button></td>';tb.appendChild(tr);});}

function openSchedModal(){document.getElementById('modalTitle').textContent='Add Schedule';var html='<form id="schedForm"><div class="form-group"><label>Date *</label><input type="date" id="s_date" required></div><div class="form-group"><label>Event *</label><input type="text" id="s_event" required></div><div class="form-row"><div class="form-group"><label>Shift</label><select id="s_shift"><option>SHIFT 1</option><option>SHIFT 2</option><option>SHIFT 3</option></select></div><div class="form-group"><label>Customer</label><input type="text" id="s_cust"></div></div></form>';document.getElementById('modalBody').innerHTML=html;document.getElementById('modalFooter').innerHTML='<button class="btn btn-secondary" onclick="closeModal()">Cancel</button><button class="btn btn-primary" onclick="saveSchedule()">Save</button>';openModal();}

function delSched(id){if(confirm('Hapus jadwal?')){DATA.schedules=DATA.schedules.filter(function(s){return s.id!==id;});save();renderCal();renderSchedTable();toast('Dihapus!','success');}}

function saveSchedule(){var dt=document.getElementById('s_date').value,ev=document.getElementById('s_event').value;if(!dt||!ev){toast('Lengkapi field!','error');return;}var s={date:dt,event:ev,shift:document.getElementById('s_shift').value,customer:document.getElementById('s_cust').value};s.id=Date.now();DATA.schedules.push(s);save();closeModal();renderCal();renderSchedTable();toast('Ditambahkan!','success');}

function resetSchedule(){if(confirm('Reset Schedule?')){DATA.schedules=JSON.parse(JSON.stringify([{id:1,date:"2026-07-20",event:"2.BLASTING & PRIMER - SO 030",shift:"SHIFT 1"},{id:2,date:"2026-07-21",event:"3.SECOND & TOP COAT - SO 030",shift:"SHIFT 1"},{id:3,date:"2026-07-22",event:"1.HYDRO - SO 002 - 4 NO'S",shift:"SHIFT 2"},{id:4,date:"2026-07-22",event:"1.HYDRO - SO 002 - Balance",shift:"SHIFT 2"},{id:5,date:"2026-07-23",event:"2.BLASTING & PRIMER - SO 002",shift:"SHIFT 1"},{id:6,date:"2026-07-25",event:"1.HYDRO - SO 012 - 8 NO'S",shift:"SHIFT 1"},{id:7,date:"2026-07-27",event:"1.HYDRO - SO 004 - 76 NO'S",shift:"SHIFT 2"},{id:8,date:"2026-07-28",event:"1.HYDRO - SO 004 - 76 NO'S",shift:"SHIFT 2"},{id:9,date:"2026-07-30",event:"1.HYDRO INSPECTION - SO 002",shift:"SHIFT 1"}]));save();renderCal();renderSchedTable();toast('Direset!','success');}}

function exportSchedExcel(){try{var data=DATA.schedules.map(function(s){return{'Date':s.date,'Event':s.event,'Shift':s.shift,'Customer':s.customer||''};});var wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(data),'Schedule');XLSX.writeFile(wb,'ALFA_Schedule.xlsx');toast('Export berhasil!','success');}catch(e){toast('Gagal!','error');}}

function importSchedExcel(ev){var f=ev.target.files[0];if(!f)return;var r=new FileReader();r.onload=function(e){try{var wb=XLSX.read(new Uint8Array(e.target.result),{type:'array'});var js=XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]);if(js.length===0){toast('File kosong!','error');return;}if(confirm('Ditemukan '+js.length+' data. Ganti?')){DATA.schedules=js.map(function(r,i){return{id:Date.now()+i,date:fd(r['Date']||''),event:r['Event']||'',shift:r['Shift']||'SHIFT 1',customer:r['Customer']||''};});save();renderCal();renderSchedTable();toast('Import berhasil!','success');}}catch(e){toast('Gagal baca!','error');}};r.readAsArrayBuffer(f);ev.target.value='';}

// ============================================================
// 8. MR LIST
// ============================================================
// ============================================================
// 8. MR LIST  (CRUD + terhubung database Tools & Consumable)
// ============================================================
var MR_STATUS=['Pending','Ordered','Received','Cancelled'];
function mrStatusClass(s){return s==='Received'?'status-success':s==='Ordered'?'status-info':s==='Cancelled'?'status-danger':'status-warning';}

// --- jembatan ke database Tools & Cons ---
function catalog(type){return type==='tools'?DATA.tools:DATA.consumables;}
function catItem(type,id){return catalog(type).find(function(x){return x.id===+id;});}
function catName(it,type){return type==='tools'?it.name:it.description;}
function catStock(it,type){return type==='tools'?(+it.qty||0):(+it.actualStock||0);}
function catSetStock(it,type,v){if(type==='tools')it.qty=v;else it.actualStock=v;recalcStatus(it,type);}
function catUnit(it,type){return type==='tools'?'Ea':(it.unit||'Ea');}
function recalcStatus(it,type){
  var st=catStock(it,type);
  if(type==='tools'){
    if(it.status==='DAMAGED'&&st>0)return;
    it.status=st<=0?'NOT AVAILABLE':'STOCK AVAILABLE';
  }else{
    it.status=st<=0?'OUT OF STOCK':(st<=(+it.safetyStock||0)?'LOW STOCK':'STOCK AVAILABLE');
  }
}
// qty pending (Pending+Ordered) yang menuju sebuah item -> "On Order"
function onOrderQty(type,id){
  return DATA.mrlist.filter(function(m){return m.itemType===type&&+m.itemId===+id&&(m.status==='Pending'||m.status==='Ordered');})
    .reduce(function(s,m){return s+(+m.qtyRequest||0);},0);
}
function mrOverdue(m){
  if(m.status==='Received'||m.status==='Cancelled'||!m.needDate)return false;
  var d=pd(m.needDate);d.setHours(0,0,0,0);var n=new Date();n.setHours(0,0,0,0);return d<n;
}

function mrFiltered(){
  var s=(S.mrSearch||'').toLowerCase(),st=S.mrStatus||'',so=S.mrSO||'',ty=S.mrItemType||'';
  return DATA.mrlist.filter(function(m){
    var ms=!s||[m.mrNo,m.soNo,m.typeValve,m.itemName,m.supplier,m.machine].some(function(v){return String(v||'').toLowerCase().indexOf(s)>=0;});
    return ms&&(!st||m.status===st)&&(!so||m.soNo===so)&&(!ty||m.itemType===ty);
  });
}
function renderMRList(c){
  var all=DATA.mrlist;
  var cnt=function(st){return all.filter(function(m){return m.status===st;}).length;};
  var od=all.filter(mrOverdue).length;
  var sos=[...new Set(all.map(function(m){return m.soNo;}))].filter(Boolean).sort();
  var kpi=function(lbl,val,sub,col){return '<div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">'+lbl+'</span><div style="font-size:24px;font-weight:700;margin-top:4px;'+(col?'color:'+col+';':'')+'">'+val+'</div>'+(sub?'<div style="font-size:10px;color:var(--muted);">'+sub+'</div>':'')+'</div>';};
  c.innerHTML='<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;flex-wrap:wrap;gap:8px;">'+
    '<div><h2 class="section-title">MR List — Material Request</h2><p class="section-subtitle">Data pending yang bisa di-input, edit & update. Terhubung ke database Tools &amp; Consumable.</p></div>'+
    '<div class="action-bar">'+
      '<input type="text" class="search-input" id="mrSearch" placeholder="Cari MR / SO / item..." value="'+esc(S.mrSearch||'')+'" oninput="mrOnFilter()">'+
      '<select class="search-input" id="mrStatus" style="max-width:130px;" onchange="mrOnFilter()"><option value="">Semua Status</option>'+MR_STATUS.map(function(x){return '<option value="'+x+'"'+(S.mrStatus===x?' selected':'')+'>'+x+'</option>';}).join('')+'</select>'+
      '<select class="search-input" id="mrSO" style="max-width:130px;" onchange="mrOnFilter()"><option value="">Semua SO</option>'+sos.map(function(x){return '<option value="'+esc(x)+'"'+(S.mrSO===x?' selected':'')+'>'+esc(x)+'</option>';}).join('')+'</select>'+
      '<select class="search-input" id="mrItemType" style="max-width:130px;" onchange="mrOnFilter()"><option value="">Semua Jenis</option><option value="consumable"'+(S.mrItemType==='consumable'?' selected':'')+'>Consumable</option><option value="tools"'+(S.mrItemType==='tools'?' selected':'')+'>Tools</option></select>'+
      '<button class="btn btn-primary btn-sm" onclick="openMRModal()">+ Input MR</button>'+
      '<button class="btn btn-secondary btn-sm" onclick="openReceiptLog()">📥 Riwayat Terima</button>'+
      '<button class="btn btn-secondary btn-sm" onclick="exportMRExcel()">↓ Excel</button>'+
    '</div></div>'+
    '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:16px;">'+
      kpi('Total MR',all.length,'baris item','')+
      kpi('Pending',cnt('Pending'),'belum dipesan','var(--warning)')+
      kpi('Ordered',cnt('Ordered'),'menunggu datang','var(--accent2)')+
      kpi('Received',cnt('Received'),'stok bertambah','var(--success)')+
      kpi('Overdue',od,'lewat need date','var(--danger)')+
    '</div>'+
    '<div class="table-container" style="overflow-x:auto;"><table class="data-table"><thead><tr>'+
      '<th>MR No</th><th>SO / Type Valve</th><th>Item (dari Tools &amp; Cons.)</th><th>Jenis</th><th style="text-align:right;">Qty Req</th><th style="text-align:right;">Stok Skrg</th><th>Need Date</th><th>Supplier</th><th>Status</th><th style="text-align:right;">Aksi</th>'+
    '</tr></thead><tbody id="mrTable"></tbody></table></div>'+
    '<div id="mrCount" style="font-size:11.5px;color:var(--muted);margin-top:10px;"></div>';
  filterMR();
}
function mrOnFilter(){
  S.mrSearch=document.getElementById('mrSearch').value;
  S.mrStatus=document.getElementById('mrStatus').value;
  S.mrSO=document.getElementById('mrSO').value;
  S.mrItemType=document.getElementById('mrItemType').value;
  filterMR();
}
function filterMR(){
  var tb=document.getElementById('mrTable');if(!tb)return;
  var data=mrFiltered();
  tb.innerHTML='';
  if(!data.length){tb.innerHTML='<tr><td colspan="10" style="text-align:center;padding:30px;color:var(--muted);">Tidak ada MR yang cocok.</td></tr>';}
  data.forEach(function(m){
    var it=catItem(m.itemType,m.itemId);
    var stock=it?catStock(it,m.itemType):null;
    var short=(stock!==null&&stock<(+m.qtyRequest||0));
    var od=mrOverdue(m);
    var tr=document.createElement('tr');
    tr.innerHTML='<td style="font-weight:600;color:var(--accent);">'+esc(m.mrNo)+'<div style="font-size:10px;color:var(--muted);font-weight:400;">'+esc(m.reqDate||'')+'</div></td>'+
      '<td><strong>'+esc(m.soNo)+'</strong><div style="font-size:10.5px;color:var(--muted);">'+esc(m.typeValve)+(m.valveQty?' • '+m.valveQty+' unit':'')+'</div></td>'+
      '<td style="font-weight:500;">'+esc(m.itemName)+(it?'':' <span class="badge status-danger">item terhapus</span>')+(m.remark?'<div style="font-size:10px;color:var(--muted);">'+esc(m.remark)+'</div>':'')+'</td>'+
      '<td><span class="badge" style="background:'+(m.itemType==='tools'?'var(--accent2-soft);color:var(--accent2)':'var(--accent-soft);color:var(--accent)')+';">'+(m.itemType==='tools'?'🔧 Tools':'📦 Cons.')+'</span></td>'+
      '<td style="text-align:right;font-weight:600;">'+(+m.qtyRequest||0)+' <span style="font-size:10px;color:var(--muted);">'+esc(m.unit||'')+'</span></td>'+
      '<td style="text-align:right;font-weight:600;color:'+(short?'var(--danger)':'var(--success)')+';">'+(stock===null?'-':stock)+'</td>'+
      '<td'+(od?' style="color:var(--danger);font-weight:600;"':'')+'>'+esc(m.needDate||'-')+(od?' ⚠':'')+'</td>'+
      '<td style="font-size:11px;">'+esc(m.supplier||'-')+'</td>'+
      '<td><span class="status-pill '+mrStatusClass(m.status)+'">'+esc(m.status)+'</span>'+(m.status==='Received'&&m.receivedDate?'<div style="font-size:9.5px;color:var(--muted);margin-top:2px;">'+esc(m.receivedDate)+' • '+(+m.receivedQty||0)+'</div>':'')+'</td>'+
      '<td style="text-align:right;white-space:nowrap;">'+
        (m.status==='Pending'?'<button class="btn btn-secondary btn-sm" onclick="mrSetStatus('+m.id+',\'Ordered\')">Order</button> ':'')+
        (m.status!=='Received'&&m.status!=='Cancelled'?'<button class="btn btn-primary btn-sm" onclick="openReceiveModal('+m.id+')">Terima</button> ':'')+
        '<button class="btn btn-info btn-sm" onclick="openMRModal('+m.id+')">Edit</button> '+
        '<button class="btn btn-danger btn-sm" onclick="delMR('+m.id+')">Hapus</button>'+
      '</td>';
    tb.appendChild(tr);
  });
  var cd=document.getElementById('mrCount');
  if(cd)cd.innerHTML='Menampilkan <strong style="color:var(--text);">'+data.length+'</strong> dari '+DATA.mrlist.length+' baris MR';
}

// ---- form input / edit ----
function mrItemOptions(type,sel){
  return catalog(type).map(function(x){
    var nm=catName(x,type),st=catStock(x,type);
    return '<option value="'+x.id+'"'+(+sel===x.id?' selected':'')+'>'+esc(nm)+' — stok '+st+' '+esc(catUnit(x,type))+'</option>';
  }).join('');
}
function mrTypeChanged(){
  var t=document.getElementById('m_itemType').value;
  document.getElementById('m_itemId').innerHTML=mrItemOptions(t,null);
  mrItemChanged();
}
function mrItemChanged(){
  var t=document.getElementById('m_itemType').value,id=document.getElementById('m_itemId').value;
  var it=catItem(t,id);var box=document.getElementById('m_stockInfo');
  if(!it||!box)return;
  var st=catStock(it,t),oo=onOrderQty(t,it.id);
  var sf=(t==='consumable'?(+it.safetyStock||0):0);
  document.getElementById('m_unit').value=catUnit(it,t);
  box.innerHTML='<div style="display:flex;gap:16px;flex-wrap:wrap;font-size:11.5px;">'+
    '<span>Stok saat ini: <strong style="color:'+(st<=sf?'var(--danger)':'var(--success)')+';">'+st+' '+esc(catUnit(it,t))+'</strong></span>'+
    (t==='consumable'?'<span>Safety stock: <strong>'+sf+'</strong></span>':'')+
    '<span>Sedang on-order: <strong style="color:var(--accent2);">'+oo+'</strong></span>'+
    '<span>Status: <span class="status-pill '+(it.status==='STOCK AVAILABLE'?'status-success':it.status==='LOW STOCK'||it.status==='DAMAGED'?'status-warning':'status-danger')+'">'+esc(it.status)+'</span></span></div>';
}
function nextMRNo(){
  var y=new Date().getFullYear();
  var n=DATA.mrlist.reduce(function(m,x){var p=/MR-\d{4}-(\d+)/.exec(x.mrNo||'');return p?Math.max(m,+p[1]):m;},0)+1;
  return 'MR-'+y+'-'+String(n).padStart(3,'0');
}
function openMRModal(id){
  var m=id?DATA.mrlist.find(function(x){return x.id===id;}):null;
  var type=m?m.itemType:'consumable';
  document.getElementById('modalTitle').textContent=m?'Edit Material Request':'Input Material Request';
  var today=new Date().toISOString().split('T')[0];
  var sos=[...new Set(DATA.projects.map(function(p){return 'SO. '+String(p.soNo||'').split('/')[0];}).concat(DATA.mrlist.map(function(x){return x.soNo;})))].filter(Boolean);
  var valves=[...new Set(DATA.projects.map(function(p){return p.partName+' '+p.size+' '+p.ansiClass+'#';}).concat(DATA.mrlist.map(function(x){return x.typeValve;})))].filter(Boolean);
  document.getElementById('modalBody').innerHTML='<form id="mrForm" onsubmit="return false;"><input type="hidden" id="m_id" value="'+(m?m.id:'')+'">'+
    '<div class="form-row"><div class="form-group"><label>MR No *</label><input id="m_no" value="'+esc(m?m.mrNo:nextMRNo())+'"></div>'+
    '<div class="form-group"><label>Tanggal Request</label><input type="date" id="m_reqDate" value="'+esc(m?m.reqDate:today)+'"></div></div>'+
    '<div class="form-row"><div class="form-group"><label>SO. No</label><input list="mrSOList" id="m_so" value="'+esc(m?m.soNo:'')+'" placeholder="SO. 015"><datalist id="mrSOList">'+sos.map(function(x){return '<option value="'+esc(x)+'">';}).join('')+'</datalist></div>'+
    '<div class="form-group"><label>Type Valve</label><input list="mrValveList" id="m_valve" value="'+esc(m?m.typeValve:'')+'" placeholder=\'BALL 6&quot; 150#\'><datalist id="mrValveList">'+valves.map(function(x){return '<option value="'+esc(x)+'">';}).join('')+'</datalist></div></div>'+
    '<div class="form-row"><div class="form-group"><label>Qty Valve</label><input type="number" id="m_vqty" min="0" value="'+(m?(m.valveQty||0):0)+'"></div>'+
    '<div class="form-group"><label>Machine</label><input id="m_mach" value="'+esc(m?m.machine:'')+'" placeholder="A1 / A3 / CNC1"></div></div>'+
    '<hr style="border:none;border-top:1px solid var(--border);margin:14px 0;">'+
    '<div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);margin-bottom:8px;">Item — diambil dari database Tools &amp; Consumable</div>'+
    '<div class="form-row"><div class="form-group"><label>Jenis Item *</label><select id="m_itemType" onchange="mrTypeChanged()"><option value="consumable"'+(type==='consumable'?' selected':'')+'>📦 Consumable</option><option value="tools"'+(type==='tools'?' selected':'')+'>🔧 Tools</option></select></div>'+
    '<div class="form-group"><label>Nama Item *</label><select id="m_itemId" onchange="mrItemChanged()">'+mrItemOptions(type,m?m.itemId:null)+'</select></div></div>'+
    '<div id="m_stockInfo" style="padding:9px 12px;background:var(--accent-soft);border-radius:8px;margin-bottom:12px;"></div>'+
    '<div class="form-row"><div class="form-group"><label>Qty Request *</label><input type="number" id="m_qty" min="1" value="'+(m?(m.qtyRequest||1):1)+'"></div>'+
    '<div class="form-group"><label>Unit</label><input id="m_unit" value="'+esc(m?m.unit:'')+'" readonly style="opacity:.7;"></div></div>'+
    '<div class="form-row"><div class="form-group"><label>Need Date</label><input type="date" id="m_need" value="'+esc(m?m.needDate:'')+'"></div>'+
    '<div class="form-group"><label>Status</label><select id="m_status">'+MR_STATUS.map(function(x){return '<option value="'+x+'"'+(m&&m.status===x?' selected':'')+'>'+x+'</option>';}).join('')+'</select></div></div>'+
    '<div class="form-row"><div class="form-group"><label>Supplier</label><input id="m_sup" value="'+esc(m?m.supplier:'')+'"></div>'+
    '<div class="form-group"><label>Keterangan</label><input id="m_rem" value="'+esc(m?m.remark:'')+'"></div></div>'+
    '<div style="font-size:11px;color:var(--muted);">Catatan: stok hanya bertambah lewat tombol <strong>Terima</strong>, bukan dari ubah status di form ini.</div></form>';
  document.getElementById('modalFooter').innerHTML='<button class="btn btn-secondary" onclick="closeModal()">Batal</button><button class="btn btn-primary" onclick="saveMR()">Simpan</button>';
  mrItemChanged();openModal();
}
function saveMR(){
  var id=document.getElementById('m_id').value;
  var type=document.getElementById('m_itemType').value;
  var itemId=+document.getElementById('m_itemId').value;
  var it=catItem(type,itemId);
  if(!it){toast('Pilih item terlebih dahulu!','error');return;}
  var qty=+document.getElementById('m_qty').value||0;
  if(qty<=0){toast('Qty Request harus lebih dari 0!','error');return;}
  var o={mrNo:document.getElementById('m_no').value.trim()||nextMRNo(),reqDate:document.getElementById('m_reqDate').value,soNo:document.getElementById('m_so').value.trim(),typeValve:document.getElementById('m_valve').value.trim(),valveQty:+document.getElementById('m_vqty').value||0,machine:document.getElementById('m_mach').value.trim(),itemType:type,itemId:itemId,itemName:catName(it,type),unit:catUnit(it,type),qtyRequest:qty,needDate:document.getElementById('m_need').value,status:document.getElementById('m_status').value,supplier:document.getElementById('m_sup').value.trim(),remark:document.getElementById('m_rem').value.trim()};
  if(id){
    var r=DATA.mrlist.find(function(x){return x.id===+id;});
    var wasRecv=r.status==='Received';
    if(wasRecv&&o.status!=='Received'){o.receivedDate='';o.receivedQty=0;}
    else{o.receivedDate=r.receivedDate||'';o.receivedQty=r.receivedQty||0;}
    if(!wasRecv&&o.status==='Received'){o.status='Ordered';toast('Gunakan tombol Terima agar stok ikut terupdate','info');}
    Object.assign(r,o);toast('MR diperbarui','success');
  }else{
    o.id=DATA.mrlist.reduce(function(m,x){return Math.max(m,x.id);},0)+1;o.receivedDate='';o.receivedQty=0;
    if(o.status==='Received'){o.status='Ordered';toast('MR dibuat — gunakan tombol Terima untuk update stok','info');}
    else toast('MR ditambahkan','success');
    DATA.mrlist.push(o);
  }
  save();closeModal();renderCurrentPage();
}
function mrSetStatus(id,st){
  var m=DATA.mrlist.find(function(x){return x.id===id;});if(!m)return;
  m.status=st;save();filterMR();renderCurrentPage();toast('Status → '+st,'success');
}
function delMR(id){
  var m=DATA.mrlist.find(function(x){return x.id===id;});if(!m)return;
  if(confirm('Hapus MR '+m.mrNo+' — '+m.itemName+'?')){DATA.mrlist=DATA.mrlist.filter(function(x){return x.id!==id;});save();renderCurrentPage();toast('MR dihapus','success');}
}

// ---- penerimaan barang: update stok Tools & Cons + catat riwayat ----
function openReceiveModal(id){
  var m=DATA.mrlist.find(function(x){return x.id===id;});if(!m)return;
  var it=catItem(m.itemType,m.itemId);
  if(!it){toast('Item tidak ada lagi di database Tools & Cons.','error');return;}
  var st=catStock(it,m.itemType);
  document.getElementById('modalTitle').textContent='Terima Barang — '+m.mrNo;
  document.getElementById('modalBody').innerHTML='<input type="hidden" id="r_id" value="'+m.id+'">'+
    '<div style="padding:11px 13px;background:var(--accent-soft);border-radius:8px;margin-bottom:14px;font-size:12px;line-height:1.7;">'+
      '<strong style="font-size:13px;">'+esc(m.itemName)+'</strong><br>'+
      'SO '+esc(m.soNo||'-')+' • '+esc(m.typeValve||'-')+'<br>'+
      'Qty diminta: <strong>'+(+m.qtyRequest||0)+' '+esc(m.unit)+'</strong> &nbsp;•&nbsp; Stok sekarang: <strong>'+st+'</strong></div>'+
    '<div class="form-row"><div class="form-group"><label>Qty Diterima *</label><input type="number" id="r_qty" min="0" value="'+(+m.qtyRequest||0)+'" oninput="recvPreview()"></div>'+
    '<div class="form-group"><label>Tanggal Terima *</label><input type="date" id="r_date" value="'+new Date().toISOString().split('T')[0]+'"></div></div>'+
    '<div class="form-row"><div class="form-group"><label>PIC Penerima</label><input id="r_pic" value="Warehouse"></div>'+
    '<div class="form-group"><label>Catatan</label><input id="r_note" placeholder="No. surat jalan / kondisi barang"></div></div>'+
    '<div id="r_prev" style="padding:10px 12px;border-radius:8px;background:rgba(22,163,74,.10);font-size:12px;"></div>';
  document.getElementById('modalFooter').innerHTML='<button class="btn btn-secondary" onclick="closeModal()">Batal</button><button class="btn btn-primary" onclick="confirmReceive()">✓ Terima &amp; Update Stok</button>';
  recvPreview();openModal();
}
function recvPreview(){
  var m=DATA.mrlist.find(function(x){return x.id===+document.getElementById('r_id').value;});
  var it=catItem(m.itemType,m.itemId);var st=catStock(it,m.itemType);
  var q=+document.getElementById('r_qty').value||0;
  var after=st+q, sf=(m.itemType==='consumable'?(+it.safetyStock||0):0);
  var ns=m.itemType==='tools'?(after<=0?'NOT AVAILABLE':'STOCK AVAILABLE'):(after<=0?'OUT OF STOCK':after<=sf?'LOW STOCK':'STOCK AVAILABLE');
  var partial=q<(+m.qtyRequest||0);
  document.getElementById('r_prev').innerHTML='Stok di tab Tools &amp; Cons.: <strong>'+st+'</strong> → <strong style="color:var(--success);">'+after+' '+esc(m.unit)+'</strong> &nbsp;•&nbsp; status jadi <span class="status-pill '+(ns==='STOCK AVAILABLE'?'status-success':ns==='LOW STOCK'?'status-warning':'status-danger')+'">'+ns+'</span>'+
    (partial?'<div style="margin-top:6px;color:var(--warning);font-weight:600;">Qty kurang dari permintaan — MR tetap berstatus Ordered (partial).</div>':'');
}
function confirmReceive(){
  var m=DATA.mrlist.find(function(x){return x.id===+document.getElementById('r_id').value;});if(!m)return;
  var it=catItem(m.itemType,m.itemId);if(!it){toast('Item tidak ditemukan','error');return;}
  var q=+document.getElementById('r_qty').value||0;
  if(q<=0){toast('Qty diterima harus > 0','error');return;}
  var before=catStock(it,m.itemType);
  catSetStock(it,m.itemType,before+q);
  m.receivedQty=(+m.receivedQty||0)+q;
  m.receivedDate=document.getElementById('r_date').value;
  m.status=(m.receivedQty>=(+m.qtyRequest||0))?'Received':'Ordered';
  DATA.receipts.push({id:DATA.receipts.reduce(function(a,x){return Math.max(a,x.id);},0)+1,date:m.receivedDate,mrNo:m.mrNo,itemType:m.itemType,itemId:m.itemId,itemName:m.itemName,unit:m.unit,qty:q,soNo:m.soNo,pic:document.getElementById('r_pic').value.trim()||'-',note:document.getElementById('r_note').value.trim()||'-',stockBefore:before,stockAfter:before+q});
  save();closeModal();renderCurrentPage();
  toast('Diterima '+q+' '+m.unit+' — stok '+m.itemName+' jadi '+(before+q),'success');
}
function openReceiptLog(){
  document.getElementById('modalTitle').textContent='Riwayat Penerimaan Barang';
  var rs=DATA.receipts.slice().sort(function(a,b){return String(b.date).localeCompare(String(a.date));});
  document.getElementById('modalBody').innerHTML=rs.length?
    '<div style="overflow-x:auto;"><table class="data-table"><thead><tr><th>Tanggal</th><th>MR No</th><th>Item</th><th>Qty</th><th>Stok</th><th>PIC</th><th>Catatan</th></tr></thead><tbody>'+
    rs.map(function(r){return '<tr><td>'+esc(r.date)+'</td><td style="font-weight:600;color:var(--accent);">'+esc(r.mrNo)+'</td><td>'+esc(r.itemName)+'<div style="font-size:10px;color:var(--muted);">'+(r.itemType==='tools'?'Tools':'Consumable')+' • '+esc(r.soNo||'-')+'</div></td><td style="font-weight:600;">+'+r.qty+' '+esc(r.unit||'')+'</td><td style="font-size:11px;">'+r.stockBefore+' → <strong style="color:var(--success);">'+r.stockAfter+'</strong></td><td style="font-size:11px;">'+esc(r.pic)+'</td><td style="font-size:11px;">'+esc(r.note)+'</td></tr>';}).join('')+
    '</tbody></table></div>':'<div style="padding:28px;text-align:center;color:var(--muted);">Belum ada riwayat penerimaan.</div>';
  document.getElementById('modalFooter').innerHTML='<button class="btn btn-secondary" onclick="exportReceiptExcel()">↓ Excel</button><button class="btn btn-primary" onclick="closeModal()">Tutup</button>';
  openModal();
}
function exportMRExcel(){
  if(typeof XLSX==='undefined'){toast('Export butuh koneksi internet','error');return;}
  try{
    var rows=mrFiltered().map(function(m){var it=catItem(m.itemType,m.itemId);return{'MR No':m.mrNo,'Req Date':m.reqDate,'SO. NO':m.soNo,'Type Valve':m.typeValve,'Qty Valve':m.valveQty,'Machine':m.machine,'Jenis':m.itemType==='tools'?'Tools':'Consumable','Item':m.itemName,'Unit':m.unit,'Qty Request':m.qtyRequest,'Qty Received':m.receivedQty||0,'Stok Saat Ini':it?catStock(it,m.itemType):'','Need Date':m.needDate,'Supplier':m.supplier,'Status':m.status,'Received Date':m.receivedDate,'Keterangan':m.remark};});
    var wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(rows),'MR List');
    XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(DATA.receipts.map(function(r){return{'Tanggal':r.date,'MR No':r.mrNo,'Item':r.itemName,'Jenis':r.itemType==='tools'?'Tools':'Consumable','Qty':r.qty,'Unit':r.unit,'SO':r.soNo,'PIC':r.pic,'Stok Sebelum':r.stockBefore,'Stok Sesudah':r.stockAfter,'Catatan':r.note};})),'Riwayat Terima');
    XLSX.writeFile(wb,'MR_List.xlsx');toast('Excel diunduh','success');
  }catch(e){toast('Gagal export','error');}
}
function exportReceiptExcel(){
  if(typeof XLSX==='undefined'){toast('Export butuh koneksi internet','error');return;}
  try{
    var wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(DATA.receipts.map(function(r){return{'Tanggal':r.date,'MR No':r.mrNo,'Item':r.itemName,'Jenis':r.itemType==='tools'?'Tools':'Consumable','Qty':r.qty,'Unit':r.unit,'SO':r.soNo,'PIC':r.pic,'Stok Sebelum':r.stockBefore,'Stok Sesudah':r.stockAfter,'Catatan':r.note};})),'Riwayat Terima');
    XLSX.writeFile(wb,'Riwayat_Penerimaan.xlsx');toast('Excel diunduh','success');
  }catch(e){toast('Gagal export','error');}
}

// ============================================================
// 9. TOOLS & CONSUMABLE
// ============================================================
function renderTools(c){var cAvail=DATA.consumables.filter(function(c){return c.status==='STOCK AVAILABLE';}).length;var cLow=DATA.consumables.filter(function(c){return c.status==='LOW STOCK';}).length;var cOut=DATA.consumables.filter(function(c){return c.status==='OUT OF STOCK';}).length;var tAvail=DATA.tools.filter(function(t){return t.status==='STOCK AVAILABLE';}).length;var tDam=DATA.tools.filter(function(t){return t.status==='DAMAGED';}).length;var tNA=DATA.tools.filter(function(t){return t.status==='NOT AVAILABLE';}).length;c.innerHTML='<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;flex-wrap:wrap;gap:8px;"><div><h2 class="section-title">Tools & Consumable</h2><p class="section-subtitle">Data stok</p></div><div class="action-bar"><input type="text" class="search-input" id="tcSearch" placeholder="Cari..." oninput="filterTC()"></div></div><div style="display:flex;gap:2px;border-bottom:1px solid var(--border);margin-bottom:14px;flex-wrap:wrap;"><button onclick="switchTCTab(\'consumable\')" id="tabConsBtn" style="padding:7px 14px;border:none;background:none;cursor:pointer;font-size:12.5px;font-weight:500;color:var(--accent);border-bottom:2px solid var(--accent);">📦 Consumable</button><button onclick="switchTCTab(\'tools\')" id="tabToolsBtn" style="padding:7px 14px;border:none;background:none;cursor:pointer;font-size:12.5px;font-weight:500;color:var(--muted);border-bottom:2px solid transparent;">🔧 Tools</button></div><div id="tabCons" style="display:block;"><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:12px;margin-bottom:18px;"><div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">Total Items</span><div style="font-size:24px;font-weight:700;margin-top:4px;">'+DATA.consumables.length+'</div></div><div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">Available</span><div style="font-size:24px;font-weight:700;color:var(--success);margin-top:4px;">'+cAvail+'</div></div><div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">Low Stock</span><div style="font-size:24px;font-weight:700;color:var(--warning);margin-top:4px;">'+cLow+'</div></div><div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">Out of Stock</span><div style="font-size:24px;font-weight:700;color:var(--danger);margin-top:4px;">'+cOut+'</div></div></div><div class="table-container" style="overflow-x:auto;"><table class="data-table"><thead><tr><th>No</th><th>Description</th><th>Unit</th><th>Safety</th><th>Actual</th><th>Status</th></tr></thead><tbody id="consTable"></tbody></table></div></div><div id="tabTools" style="display:none;"><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:12px;margin-bottom:18px;"><div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">Total Tools</span><div style="font-size:24px;font-weight:700;margin-top:4px;">'+DATA.tools.length+'</div></div><div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">Available</span><div style="font-size:24px;font-weight:700;color:var(--success);margin-top:4px;">'+tAvail+'</div></div><div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">Damaged</span><div style="font-size:24px;font-weight:700;color:var(--warning);margin-top:4px;">'+tDam+'</div></div><div class="kpi-card"><span style="font-size:10.5px;color:var(--muted);text-transform:uppercase;font-weight:600;">Not Available</span><div style="font-size:24px;font-weight:700;color:var(--danger);margin-top:4px;">'+tNA+'</div></div></div><div class="table-container" style="overflow-x:auto;"><table class="data-table"><thead><tr><th>Tool Name</th><th>Size/Type</th><th>Merk</th><th>Location</th><th>Qty</th><th>Category</th><th>Status</th></tr></thead><tbody id="toolsTable"></tbody></table></div></div>';filterTC();}

function switchTCTab(tab){S.tcTab=tab;document.getElementById('tabCons').style.display=tab==='consumable'?'block':'none';document.getElementById('tabTools').style.display=tab==='tools'?'block':'none';document.getElementById('tabConsBtn').style.cssText=tab==='consumable'?'padding:7px 14px;border:none;background:none;cursor:pointer;font-size:12.5px;font-weight:500;color:var(--accent);border-bottom:2px solid var(--accent);':'padding:7px 14px;border:none;background:none;cursor:pointer;font-size:12.5px;font-weight:500;color:var(--muted);border-bottom:2px solid transparent;';document.getElementById('tabToolsBtn').style.cssText=tab==='tools'?'padding:7px 14px;border:none;background:none;cursor:pointer;font-size:12.5px;font-weight:500;color:var(--accent);border-bottom:2px solid var(--accent);':'padding:7px 14px;border:none;background:none;cursor:pointer;font-size:12.5px;font-weight:500;color:var(--muted);border-bottom:2px solid transparent;';filterTC();}

function filterTC(){var s=document.getElementById('tcSearch').value.toLowerCase();var tb1=document.getElementById('consTable');var tb2=document.getElementById('toolsTable');if(tb1){tb1.innerHTML='';var dataC=DATA.consumables.filter(function(c){return!s||(c.description||'').toLowerCase().includes(s);});dataC.forEach(function(c,i){var sc=c.status==='STOCK AVAILABLE'?'status-success':c.status==='LOW STOCK'?'status-warning':'status-danger';var tr=document.createElement('tr');tr.innerHTML='<td>'+(i+1)+'</td><td style="font-weight:500;">'+c.description+'</td><td>'+c.unit+'</td><td>'+c.safetyStock+'</td><td style="font-weight:600;color:'+(c.actualStock<=c.safetyStock?'var(--danger)':'var(--text)')+';">'+c.actualStock+'</td><td><span class="status-pill '+sc+'">'+c.status+'</span></td>';tb1.appendChild(tr);});}if(tb2){tb2.innerHTML='';var dataT=DATA.tools.filter(function(t){return!s||(t.name||'').toLowerCase().includes(s)||(t.category||'').toLowerCase().includes(s);});dataT.forEach(function(t){var sc=t.status==='STOCK AVAILABLE'?'status-success':t.status==='DAMAGED'?'status-warning':'status-danger';var tr=document.createElement('tr');tr.innerHTML='<td style="font-weight:500;">'+t.name+'</td><td>'+t.sizeType+'</td><td>'+t.merk+'</td><td>'+t.location+'</td><td style="font-weight:600;">'+t.qty+'</td><td>'+t.category+'</td><td><span class="status-pill '+sc+'">'+t.status+'</span></td>';tb2.appendChild(tr);});}}

// ============================================================
// 10. REPORTS
// ============================================================
function renderReports(c){c.innerHTML='<div style="margin-bottom:14px;"><h2 class="section-title">Reports</h2><p class="section-subtitle">Download laporan Excel</p></div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:14px;"><div class="kpi-card" style="cursor:pointer;" onclick="exportProjExcel()"><div style="display:flex;align-items:flex-start;gap:12px;"><div style="width:44px;height:44px;border-radius:10px;background:rgba(22,163,74,.12);display:flex;align-items:center;justify-content:center;color:#16a34a;flex-shrink:0;font-size:20px;">📋</div><div style="flex:1;"><h3 style="font-size:13px;font-weight:600;margin:0 0 3px 0;">Detail Projects</h3><p style="font-size:11.5px;color:var(--muted);margin:0 0 8px 0;">Export ke Excel</p><span class="btn btn-primary btn-sm">↓ Download</span></div></div></div><div class="kpi-card" style="cursor:pointer;" onclick="exportVarExcel()"><div style="display:flex;align-items:flex-start;gap:12px;"><div style="width:44px;height:44px;border-radius:10px;background:rgba(217,119,6,.12);display:flex;align-items:center;justify-content:center;color:#d97706;flex-shrink:0;font-size:20px;">📊</div><div style="flex:1;"><h3 style="font-size:13px;font-weight:600;margin:0 0 3px 0;">Variance Analysis</h3><p style="font-size:11.5px;color:var(--muted);margin:0 0 8px 0;">Export ke Excel</p><span class="btn btn-secondary btn-sm">↓ Download</span></div></div></div><div class="kpi-card" style="cursor:pointer;" onclick="exportCapExcel()"><div style="display:flex;align-items:flex-start;gap:12px;"><div style="width:44px;height:44px;border-radius:10px;background:rgba(37,99,235,.12);display:flex;align-items:center;justify-content:center;color:#2563eb;flex-shrink:0;font-size:20px;">⏱</div><div style="flex:1;"><h3 style="font-size:13px;font-weight:600;margin:0 0 3px 0;">Capacity Summary</h3><p style="font-size:11.5px;color:var(--muted);margin:0 0 8px 0;">Semua Type Valve</p><span class="btn btn-secondary btn-sm">↓ Download</span></div></div></div><div class="kpi-card" style="cursor:pointer;" onclick="exportMRExcel()"><div style="display:flex;align-items:flex-start;gap:12px;"><div style="width:44px;height:44px;border-radius:10px;background:rgba(196,112,70,.14);display:flex;align-items:center;justify-content:center;color:#c47046;flex-shrink:0;font-size:20px;">📦</div><div style="flex:1;"><h3 style="font-size:13px;font-weight:600;margin:0 0 3px 0;">MR List + Riwayat</h3><p style="font-size:11.5px;color:var(--muted);margin:0 0 8px 0;">Material request &amp; penerimaan</p><span class="btn btn-secondary btn-sm">↓ Download</span></div></div></div><div class="kpi-card" style="cursor:pointer;" onclick="exportSchedExcel()"><div style="display:flex;align-items:flex-start;gap:12px;"><div style="width:44px;height:44px;border-radius:10px;background:rgba(124,58,237,.12);display:flex;align-items:center;justify-content:center;color:#7c3aed;flex-shrink:0;font-size:20px;">📅</div><div style="flex:1;"><h3 style="font-size:13px;font-weight:600;margin:0 0 3px 0;">Schedule Calendar</h3><p style="font-size:11.5px;color:var(--muted);margin:0 0 8px 0;">Export ke Excel</p><span class="btn btn-secondary btn-sm">↓ Download</span></div></div></div></div>';}

// ============================================================
// INISIALISASI APLIKASI (dipanggil oleh sync layer)
// ============================================================
window.__alfaInit=function(){
  load();
  if(S.theme==='dark'){document.documentElement.setAttribute('data-theme','dark');var tb=document.getElementById('themeBtn');if(tb)tb.textContent='\u263e';}
  setLang(S.lang);
  renderNav();
  renderCurrentPage();
};
window.__alfaRerender=function(){ renderNav(); renderCurrentPage(); };
window.addEventListener('resize',function(){if(window.__ch1)window.__ch1.resize();if(window.__ch2)window.__ch2.resize();});

window.DATA=DATA;window.S=S;window.SK=SK;window.toast=toast;window.save=save;
