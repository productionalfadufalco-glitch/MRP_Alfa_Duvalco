/* ============================================================
   ALFA VALVES MRP - LIVE SYNC CLIENT
   - Boots app state from the server database
   - Pushes changes (debounced, diff-based) over REST
   - Receives realtime updates from other devices over WebSocket
   - Offline queue: keeps working without network, flushes on reconnect
   ============================================================ */
(function () {
  'use strict';

  var COLLECTIONS = ['projects', 'variance', 'schedules', 'capacity',
                     'mrlist', 'receipts', 'consumables', 'tools', 'machines'];

  /* Per-TAB id (never persisted): echo-suppression must be per connection,
     otherwise two tabs on the same PC would silently ignore each other. */
  var CLIENT_ID = 'c' + Math.random().toString(36).slice(2) + Date.now().toString(36);

  /* Stable per-device id, used only for labelling/audit. */
  var DEVICE_ID = (function () {
    var k = 'alfa_device_id', v = null;
    try { v = localStorage.getItem(k); } catch (e) {}
    if (!v) {
      v = 'd' + Math.random().toString(36).slice(2);
      try { localStorage.setItem(k, v); } catch (e) {}
    }
    return v;
  })();

  var ALFA = {
    clientId: CLIENT_ID,
    deviceId: DEVICE_ID,
    rev: 0,
    online: false,
    ws: null,
    user: 'anon',
    token: null,
    pending: false,
    lastSync: null,
    clients: 1,
    reconnectDelay: 1000,
    dirty: {},          // collection -> true
    applyingRemote: false
  };
  window.ALFA = ALFA;

  try { ALFA.token = localStorage.getItem('alfa_token') || null; } catch (e) {}
  try { ALFA.user = localStorage.getItem('alfa_user') || 'anon'; } catch (e) {}

  /* ---------------- helpers ---------------- */
  function headers() {
    var h = { 'Content-Type': 'application/json', 'X-Client-Id': CLIENT_ID };
    if (ALFA.token) h['X-Alfa-Token'] = ALFA.token;
    return h;
  }
  function api(path, opts) {
    opts = opts || {};
    opts.headers = headers();
    if (opts.body && typeof opts.body !== 'string') opts.body = JSON.stringify(opts.body);
    return fetch(path, opts).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    });
  }
  function snapshot() {
    var o = {};
    COLLECTIONS.forEach(function (c) { o[c] = (window.DATA && DATA[c]) ? DATA[c] : []; });
    return o;
  }

  /* ---------------- status pill in the header ---------------- */
  function ensureBadge() {
    var el = document.getElementById('alfaSyncBadge');
    if (el) return el;
    var host = document.querySelector('.header > div:last-child');
    if (!host) return null;
    el = document.createElement('div');
    el.id = 'alfaSyncBadge';
    el.style.cssText = 'display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border-radius:20px;' +
      'font-size:11px;font-weight:600;border:1px solid var(--border);background:var(--card);cursor:pointer;';
    el.title = 'Status koneksi database. Klik untuk detail.';
    el.onclick = showSyncInfo;
    host.insertBefore(el, host.firstChild);
    return el;
  }
  function paint() {
    var el = ensureBadge();
    if (!el) return;
    var color = ALFA.online ? 'var(--success)' : 'var(--danger)';
    var label = ALFA.online ? ('LIVE' + (ALFA.clients > 1 ? ' \u00b7 ' + ALFA.clients : '')) : 'OFFLINE';
    if (ALFA.pending) { color = 'var(--warning)'; label = 'SYNC\u2026'; }
    el.innerHTML = '<span style="width:8px;height:8px;border-radius:50%;background:' + color +
      ';display:inline-block;' + (ALFA.online && !ALFA.pending ? 'animation:alfaPulse 2s infinite;' : '') + '"></span>' +
      '<span style="color:' + color + '">' + label + '</span>';
  }
  var st = document.createElement('style');
  st.textContent = '@keyframes alfaPulse{0%,100%{opacity:1}50%{opacity:.35}}';
  document.head.appendChild(st);

  function showSyncInfo() {
    fetch('/api/health').then(function (r) { return r.json(); }).then(function (h) {
      var rows = '';
      Object.keys(h.collections || {}).forEach(function (k) {
        rows += '<tr><td style="padding:4px 8px;">' + k + '</td><td style="padding:4px 8px;text-align:right;font-weight:600;">' +
          h.collections[k].rows + '</td><td style="padding:4px 8px;text-align:right;color:var(--muted);">' +
          (h.collections[k].bytes / 1024).toFixed(1) + ' KB</td></tr>';
      });
      var body =
        '<div style="font-size:12px;line-height:1.7;">' +
        '<div><strong>Status:</strong> <span style="color:' + (ALFA.online ? 'var(--success)' : 'var(--danger)') + '">' +
          (ALFA.online ? 'Terhubung (live)' : 'Terputus \u2014 mode offline') + '</span></div>' +
        '<div><strong>Perangkat aktif:</strong> ' + (h.clients || 1) + '</div>' +
        '<div><strong>Revisi data:</strong> ' + h.rev + '</div>' +
        '<div><strong>File database:</strong> <code style="font-size:11px;">' + h.dbFile + '</code></div>' +
        '<div><strong>Ukuran DB:</strong> ' + h.dbSize + ' (WAL ' + (h.walBytes / 1024).toFixed(0) + ' KB)</div>' +
        '<div><strong>Mode jurnal:</strong> ' + h.journalMode + ' \u00b7 <strong>Audit:</strong> ' + h.auditEntries + ' entri</div>' +
        '<div><strong>Sync terakhir:</strong> ' + (ALFA.lastSync ? ALFA.lastSync.toLocaleTimeString('id-ID') : '-') + '</div>' +
        '<table style="width:100%;margin-top:10px;border-collapse:collapse;font-size:11.5px;">' +
        '<thead><tr style="background:var(--accent-soft);"><th style="padding:5px 8px;text-align:left;">Tabel</th>' +
        '<th style="padding:5px 8px;text-align:right;">Baris</th><th style="padding:5px 8px;text-align:right;">Ukuran</th></tr></thead>' +
        '<tbody>' + rows + '</tbody></table></div>';
      openInfoModal('Status Database & Sinkronisasi', body,
        '<button class="btn btn-secondary btn-sm" onclick="ALFA.backup()">\u2193 Backup Sekarang</button>' +
        '<button class="btn btn-secondary btn-sm" onclick="window.open(\'/api/export/json\')">\u2193 Export JSON</button>' +
        '<button class="btn btn-primary btn-sm" onclick="ALFA.pull(true)">\u21bb Muat Ulang</button>');
    });
  }
  function openInfoModal(title, body, footer) {
    var t = document.getElementById('modalTitle'),
        b = document.getElementById('modalBody'),
        f = document.getElementById('modalFooter');
    if (!t) return;
    t.textContent = title;
    b.innerHTML = body;
    f.innerHTML = (footer || '') + '<button class="btn btn-secondary btn-sm" onclick="closeModal()">Tutup</button>';
    document.getElementById('modalBox').classList.add('active');
  }

  /* ---------------- offline queue ---------------- */
  function queueOffline() {
    try { localStorage.setItem('alfa_offline_queue', JSON.stringify({ at: Date.now(), data: snapshot() })); } catch (e) {}
  }
  function flushOffline() {
    var raw = null;
    try { raw = localStorage.getItem('alfa_offline_queue'); } catch (e) {}
    if (!raw) return Promise.resolve();
    var q; try { q = JSON.parse(raw); } catch (e) { return Promise.resolve(); }
    return api('/api/sync', { method: 'POST', body: q.data }).then(function (r) {
      try { localStorage.removeItem('alfa_offline_queue'); } catch (e) {}
      if (r.changed > 0 && window.toast) toast('Perubahan offline tersimpan ke server (' + r.changed + ')', 'success');
    }).catch(function () {});
  }

  /* ---------------- push (debounced, diff-based) ---------------- */
  var pushTimer = null;
  ALFA.push = function (opts) {
    if (ALFA.applyingRemote) return;             // don't echo remote updates back
    COLLECTIONS.forEach(function (c) { ALFA.dirty[c] = true; });
    ALFA.pending = true; paint();
    clearTimeout(pushTimer);
    pushTimer = setTimeout(doPush, (opts && opts.immediate) ? 0 : 350);
  };

  /* Last payload actually accepted by the server, per collection.
     Lets us send ONLY what changed instead of the whole dataset. */
  var lastSent = {};

  function doPush() {
    if (!ALFA.online) { queueOffline(); ALFA.pending = false; paint(); return; }

    var full = snapshot();
    var payload = {};
    var changedCollections = [];
    COLLECTIONS.forEach(function (c) {
      var json = JSON.stringify(full[c]);
      if (lastSent[c] !== json) { payload[c] = full[c]; changedCollections.push(c); }
    });

    // Settings ride along separately (tiny)
    var settings = JSON.stringify({ theme: S.theme, lang: S.lang });
    if (lastSent.__settings !== settings) {
      api('/api/settings', { method: 'POST', body: { theme: S.theme, lang: S.lang } })
        .then(function () { lastSent.__settings = settings; }).catch(function () {});
    }

    if (changedCollections.length === 0) { ALFA.pending = false; paint(); return; }

    api('/api/sync', { method: 'POST', body: payload })
      .then(function (r) {
        ALFA.rev = r.rev;
        ALFA.pending = false;
        ALFA.lastSync = new Date();
        ALFA.dirty = {};
        changedCollections.forEach(function (c) { lastSent[c] = JSON.stringify(full[c]); });
        paint();
      })
      .catch(function () {
        ALFA.online = false;
        ALFA.pending = false;
        queueOffline();
        paint();
      });
  }

  /* Keep the baseline in step with data that arrived FROM the server,
     so an incoming update is never bounced straight back. */
  function markSynced() {
    var full = snapshot();
    COLLECTIONS.forEach(function (c) { lastSent[c] = JSON.stringify(full[c]); });
  }

  /* ---------------- pull ---------------- */
  ALFA.pull = function (showToast) {
    return api('/api/state').then(function (r) {
      ALFA.rev = r.rev;
      applyRemote(r.data, r.settings);
      if (showToast && window.toast) toast('Data dimuat ulang dari server', 'success');
      return r;
    });
  };

  function applyRemote(data, settings) {
    if (!window.applyServerData) return;
    ALFA.applyingRemote = true;
    var payload = {};
    COLLECTIONS.forEach(function (c) { if (data[c]) payload[c] = data[c]; });
    if (settings) { if (settings.theme) payload.theme = settings.theme; if (settings.lang) payload.lang = settings.lang; }
    // force-assign even empty arrays so deletions propagate
    COLLECTIONS.forEach(function (c) { if (Array.isArray(data[c])) window.DATA[c] = data[c]; });
    window.applyServerData(payload);
    if (window.__alfaRerender) window.__alfaRerender();
    ALFA.applyingRemote = false;
    markSynced();
    ALFA.lastSync = new Date();
    paint();
  }

  /* ---------------- websocket ---------------- */
  function connect() {
    var proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    var url = proto + '//' + location.host + '/ws';
    var ws;
    try { ws = new WebSocket(url); } catch (e) { scheduleReconnect(); return; }
    ALFA.ws = ws;

    ws.onopen = function () {
      ALFA.online = true;
      ALFA.reconnectDelay = 1000;
      ws.send(JSON.stringify({ type: 'ident', clientId: CLIENT_ID, user: ALFA.user }));
      paint();
      flushOffline();
    };

    ws.onmessage = function (ev) {
      var m; try { m = JSON.parse(ev.data); } catch (e) { return; }

      if (m.type === 'hello') {
        ALFA.rev = m.rev;
        ALFA.clients = m.clients || 1;
        if (!window.__ALFA_BOOTED) {
          window.__ALFA_BOOT = buildBoot(m.data, m.settings);
          window.__ALFA_BOOTED = true;
          if (window.__alfaInit) window.__alfaInit();
          markSynced();
        } else {
          applyRemote(m.data, m.settings);
        }
        paint();
        return;
      }
      if (m.type === 'presence') { ALFA.clients = m.clients; paint(); return; }

      if (m.type === 'collection') {
        ALFA.applyingRemote = true;
        window.DATA[m.collection] = m.rows;
        ALFA.rev = m.rev;
        if (window.__alfaRerender) window.__alfaRerender();
        ALFA.applyingRemote = false;
        markSynced();
        ALFA.lastSync = new Date();
        if (window.toast) toast('Data "' + m.collection + '" diperbarui oleh pengguna lain', 'info');
        paint();
        return;
      }
      if (m.type === 'state') { applyRemote(m.data, m.settings); ALFA.rev = m.rev; return; }
      if (m.type === 'record') {
        var arr = window.DATA[m.collection] || [];
        var i = arr.findIndex(function (x) { return String(x.id) === String(m.record.id); });
        if (i >= 0) arr[i] = m.record; else arr.push(m.record);
        ALFA.applyingRemote = true;
        if (window.__alfaRerender) window.__alfaRerender();
        ALFA.applyingRemote = false;
        markSynced();
        return;
      }
      if (m.type === 'delete') {
        window.DATA[m.collection] = (window.DATA[m.collection] || []).filter(function (x) { return String(x.id) !== String(m.id); });
        ALFA.applyingRemote = true;
        if (window.__alfaRerender) window.__alfaRerender();
        ALFA.applyingRemote = false;
        markSynced();
        return;
      }
    };

    ws.onclose = function () { ALFA.online = false; paint(); scheduleReconnect(); };
    ws.onerror = function () { try { ws.close(); } catch (e) {} };
  }

  function scheduleReconnect() {
    setTimeout(connect, ALFA.reconnectDelay);
    ALFA.reconnectDelay = Math.min(ALFA.reconnectDelay * 1.6, 15000);
  }

  function buildBoot(data, settings) {
    var b = {};
    COLLECTIONS.forEach(function (c) { if (Array.isArray(data[c]) && data[c].length) b[c] = data[c]; });
    if (settings) { b.theme = settings.theme; b.lang = settings.lang; }
    return b;
  }

  /* ---------------- admin actions ---------------- */
  ALFA.backup = function () {
    api('/api/backup', { method: 'POST' }).then(function (r) {
      if (window.toast) toast('Backup dibuat: ' + r.file + ' (' + (r.bytes / 1024).toFixed(0) + ' KB)', 'success');
    }).catch(function () { if (window.toast) toast('Backup gagal', 'error'); });
  };
  ALFA.forceSync = function () { ALFA.push({ immediate: true }); };

  /* ---------------- boot ---------------- */
  function boot() {
    paint();
    // 1. Try the REST snapshot first (fast, works even if WS is blocked)
    api('/api/state')
      .then(function (r) {
        ALFA.rev = r.rev;
        var empty = COLLECTIONS.every(function (c) { return !r.data[c] || r.data[c].length === 0; });
        if (empty) {
          // First ever boot: seed the DB from the app's built-in dataset
          window.__ALFA_BOOT = null;
          window.__ALFA_BOOTED = true;
          if (window.__alfaInit) window.__alfaInit();
          return api('/api/seed', { method: 'POST', body: snapshot() }).then(function () {
            if (window.toast) toast('Database diinisialisasi dengan data awal', 'success');
          });
        }
        window.__ALFA_BOOT = buildBoot(r.data, r.settings);
        window.__ALFA_BOOTED = true;
        if (window.__alfaInit) window.__alfaInit();
        markSynced();
      })
      .catch(function () {
        // Server unreachable -> run from localStorage cache
        window.__ALFA_BOOT = null;
        window.__ALFA_BOOTED = true;
        if (window.__alfaInit) window.__alfaInit();
        if (window.toast) toast('Server tidak terjangkau \u2014 mode offline (data lokal)', 'error');
      })
      .then(function () { connect(); paint(); });

    // Periodic safety pull (in case a WS message was missed)
    setInterval(function () {
      if (ALFA.online && !ALFA.pending) {
        api('/api/changes?since=' + ALFA.rev).then(function (r) {
          if (r.rev > ALFA.rev && r.changes.length) ALFA.pull(false);
        }).catch(function () {});
      }
    }, 60000);

    window.addEventListener('beforeunload', function () {
      if (ALFA.pending) { try { navigator.sendBeacon('/api/sync', JSON.stringify(snapshot())); } catch (e) {} }
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
