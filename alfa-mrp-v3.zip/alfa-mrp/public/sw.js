/* ALFA MRP service worker — caches the app shell so it opens offline.
   API traffic is ALWAYS network-first: data must never be served stale. */
const CACHE = 'alfa-mrp-v1';
const SHELL = [
  '/', '/index.html',
  '/css/app.css', '/css/mobile.css',
  '/js/app-core.js', '/js/alfa-sync.js',
  '/vendor/echarts.min.js', '/vendor/xlsx.full.min.js',
  '/logo.svg', '/manifest.webmanifest'
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET') return;
  if (url.pathname.startsWith('/api/') || url.pathname === '/ws') return; // never cache data

  e.respondWith(
    caches.match(e.request).then(hit => {
      const net = fetch(e.request).then(res => {
        if (res && res.status === 200 && res.type === 'basic') {
          const copy = res.clone();
          caches.open(CACHE).then(c => c.put(e.request, copy));
        }
        return res;
      }).catch(() => hit);
      return hit || net;
    })
  );
});
